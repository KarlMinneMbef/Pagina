import "./embed.css";
export interface PaginaLightProps {
    /** Contenu Markdown de départ. */
    value: string;
    /** Markdown complet (commentaires de mise en page inclus) à chaque modification. */
    onChange: (markdown: string) => void;
    /** Demande d'enregistrement (Ctrl+S) — facultatif. */
    onSave?: () => void;
    /** Nom affiché, disponible comme variable `{{filename}}` dans l'en-tête/pied de page. */
    documentTitle?: string;
    /** Hauteur totale du composant (ruban compris) : nombre de pixels ou toute valeur CSS. Défaut : 640. */
    height?: number | string;
    /** Change de valeur pour recharger `value` (ex. après « Régénérer »). */
    resetKey?: string | number;
    /** Lecture seule (document figé) : ruban désactivé, aucune saisie. */
    readOnly?: boolean;
}
export declare function PaginaLight({ value, onChange, onSave, documentTitle, height, resetKey, readOnly }: PaginaLightProps): import("react").JSX.Element;
