/**
 * Taille de police : Tiptap ne fournit pas d'extension officielle stable pour
 * ça (seulement une version "next" instable), donc on ajoute un attribut
 * `fontSize` sur la marque `textStyle` — technique standard documentée par
 * Tiptap lui-même pour ce cas précis.
 *
 * Compatibilité Markdown : la taille de police n'a pas d'équivalent en
 * Markdown standard. Sérialisée en `<span style="font-size:…">` via le
 * fallback HTML de tiptap-markdown (Markdown.configure({ html: true })) :
 * lisible et correctement rendu par toute autre moteur Markdown→HTML
 * (GitHub, VS Code, Obsidian…), juste pas comme de la syntaxe Markdown pure.
 */
import { Extension } from "@tiptap/core";
export interface FontSizeOptions {
    types: string[];
}
declare module "@tiptap/core" {
    interface Commands<ReturnType> {
        fontSize: {
            setFontSize: (size: string) => ReturnType;
            unsetFontSize: () => ReturnType;
        };
    }
}
export declare const FontSize: Extension<FontSizeOptions, any>;
