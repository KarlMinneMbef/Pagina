export declare const TableMarkdown: import("@tiptap/core").Node<import("@tiptap/extension-table").TableOptions, any>;
