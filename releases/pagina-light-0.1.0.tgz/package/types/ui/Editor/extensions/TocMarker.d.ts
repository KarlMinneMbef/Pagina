/**
 * Marqueur de sommaire. Persisté dans le Markdown sous forme d'un
 * commentaire HTML standard `<!-- toc -->` (invisible et sans casse dans
 * tout autre outil Markdown), rendu à l'écran comme un encart "Sommaire —
 * cliquez sur Générer/Mettre à jour". Même principe que `PageBreak.ts`
 * (voir ce fichier pour le détail du pipeline de parsing markdown-it).
 *
 * Fonctionnement voulu (choisi explicitement, pas le seul possible) : le
 * marqueur est REMPLACÉ par une vraie liste Markdown (texte réel, pas un
 * calcul d'affichage) au clic sur "Générer" — donc lisible et navigable
 * dans n'importe quel autre outil Markdown, comme tout le reste du document.
 * Limite acceptée : une fois généré, le marqueur a disparu (remplacé) ; pour
 * régénérer un sommaire à jour après avoir ajouté des titres, il faut
 * supprimer l'ancienne liste et insérer un nouveau `<!-- toc -->` — pas de
 * marqueur de fin caché pour retrouver automatiquement les bornes d'un
 * sommaire déjà généré (aurait ajouté une complexité et un risque de
 * corruption pas demandés).
 */
import { Node } from "@tiptap/core";
declare module "@tiptap/core" {
    interface Commands<ReturnType> {
        tocMarker: {
            insertTocMarker: () => ReturnType;
            generateToc: () => ReturnType;
        };
    }
}
export declare const TocMarker: Node<any, {
    markdown: {
        serialize(state: any, node: any): void;
        parse: {
            setup(markdownit: any): void;
        };
    };
}>;
