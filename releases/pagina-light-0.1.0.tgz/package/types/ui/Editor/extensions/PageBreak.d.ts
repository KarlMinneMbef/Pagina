/**
 * Nœud "Saut de page". Persisté dans le Markdown sous forme d'un commentaire
 * HTML standard `<!-- pagebreak -->` (invisible et sans casse dans tout autre
 * outil Markdown), mais rendu à l'écran comme une ligne "Saut de page".
 *
 * Pipeline de parsing (voir tiptap-markdown) : markdown-it transforme le texte
 * en HTML, puis ProseMirror parse ce HTML via parseHTML() ci-dessous. On
 * ajoute donc une règle de bloc markdown-it (repère la ligne) + une règle de
 * rendu (émet le HTML que parseHTML sait reconnaître).
 */
import { Node } from "@tiptap/core";
export declare const PageBreak: Node<any, {
    markdown: {
        serialize(state: any, node: any): void;
        parse: {
            setup(markdownit: any): void;
        };
    };
}>;
