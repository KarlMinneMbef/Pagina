export declare const ParagraphMarkdown: import("@tiptap/core").Node<import("@tiptap/extension-paragraph").ParagraphOptions, any>;
