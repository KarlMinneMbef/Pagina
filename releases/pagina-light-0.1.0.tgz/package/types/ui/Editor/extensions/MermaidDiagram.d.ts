/**
 * Diagrammes Mermaid — persistés en bloc de code fenced Markdown standard
 * (```mermaid ... ```, la convention GitHub/GitLab/Obsidian), rendus comme
 * un vrai diagramme SVG dans l'éditeur (via la bibliothèque `mermaid`),
 * avec la source éditable juste au-dessus.
 *
 * PARSING (Markdown → document) : PAS de règle markdown-it dédiée — un
 * bloc ```mermaid est syntaxiquement un bloc de code fence tout à fait
 * normal, déjà entièrement pris en charge par `CodeBlockLowlight`
 * (`MarkdownEditor.tsx`). On laisse le pipeline standard produire
 * `<pre><code class="language-mermaid">…</code></pre>`, puis on le
 * TRANSFORME en `<div data-type="mermaid">` via le hook `updateDOM` de
 * tiptap-markdown (appelé sur le HTML complet, APRÈS le rendu markdown-it
 * mais AVANT la conversion HTML→ProseMirror) — measure documentée par
 * l'extension `codeBlock` de tiptap-markdown elle-même
 * (`node_modules/tiptap-markdown/src/extensions/nodes/code-block.js`,
 * `updateDOM` y nettoie déjà le HTML du bloc de code), donc un point
 * d'extension prévu pour exactement ce genre de post-traitement.
 *
 * Rendu : NodeView Tiptap manuel (pas de contenu ProseMirror éditable
 * classique) — un `<textarea>` pour la source, un `<div>` pour le SVG
 * rendu par `mermaid.render()` (asynchrone, ré-appelé à chaque frappe dans
 * le textarea). La source est stockée comme ATTRIBUT du nœud
 * (`node.attrs.source`), pas comme contenu ProseMirror : plus simple à
 * synchroniser avec un `<textarea>` HTML natif qu'un vrai schéma de texte
 * édité au clavier caractère par caractère.
 */
import { Node } from "@tiptap/core";
export declare const MermaidDiagram: Node<any, {
    markdown: {
        serialize(state: any, node: any): void;
        parse: {
            updateDOM(element: HTMLElement): void;
        };
    };
}>;
