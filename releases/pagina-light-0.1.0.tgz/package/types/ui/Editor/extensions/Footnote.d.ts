/**
 * Notes de bas de page — en réalité des notes de FIN DE DOCUMENT (choix
 * assumé, voir CLAUDE.md) : une vraie note « en bas de CHAQUE page » serait
 * bien plus complexe avec notre système de pagination (il faudrait savoir
 * sur quelle page atterrit chaque référence, potentiellement différent à
 * chaque frappe).
 *
 * Deux nœuds Tiptap, syntaxe Markdown standard (identique à ce que
 * produisent Pandoc/GFM-footnotes) :
 * - `FootnoteReference` (inline, atome) : `[^1]` dans le texte, rendu en
 *   exposant cliquable (saute à sa définition).
 * - `FootnoteDefinition` (bloc, contenu éditable normal) : `[^1]: Texte de
 *   la note.`, généralement en fin de document.
 *
 * Même principe de parsing/sérialisation que `PageBreak.ts`/`TocMarker.ts`
 * (règles markdown-it manuelles + parseHTML/renderHTML Tiptap), mais
 * `FootnoteDefinition` a un contenu RÉEL (`inline*`, pas juste un
 * commentaire opaque) : la règle de bloc doit donc pousser un token
 * "inline" séparé (comme le fait markdown-it pour un paragraphe normal),
 * pas produire un unique token auto-fermant.
 *
 * Numérotation : l'`id` (ex. "1") est celui choisi à la création
 * (`insertFootnote` dans MarkdownEditor.tsx, calculé comme "1 + le plus
 * grand id déjà utilisé"), PAS recalculé automatiquement à chaque frappe
 * comme la numérotation des titres — supprimer une note au milieu ne
 * renumérote pas les suivantes (comportement simple et prévisible, comme
 * la plupart des implémentations Markdown basiques).
 */
import { Node } from "@tiptap/core";
declare module "@tiptap/core" {
    interface Commands<ReturnType> {
        footnote: {
            insertFootnoteReference: (id: string) => ReturnType;
            insertFootnoteDefinition: (id: string) => ReturnType;
        };
    }
}
export declare const FootnoteReference: Node<any, {
    markdown: {
        serialize(state: any, node: any): void;
        parse: {
            setup(markdownit: any): void;
        };
    };
}>;
export declare const FootnoteDefinition: Node<any, {
    markdown: {
        serialize(state: any, node: any): void;
        parse: {
            setup(markdownit: any): void;
        };
    };
}>;
