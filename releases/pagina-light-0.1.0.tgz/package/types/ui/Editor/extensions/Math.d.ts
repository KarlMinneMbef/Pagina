/**
 * Formules mathématiques LaTeX — `$formule$` en ligne, `$$formule$$` en
 * bloc (convention Pandoc/GFM la plus répandue). Rendu STATIQUE via KaTeX
 * (`katex.renderToString`, synchrone — pas besoin de NodeView asynchrone
 * comme pour Mermaid). Édition : clic sur une formule déjà rendue → invite
 * (`window.prompt`, même schéma que `setLink`/`insertImage` ailleurs dans
 * ce projet) pré-remplie avec la source LaTeX actuelle — voir le
 * gestionnaire de clic dans `MarkdownEditor.tsx`.
 *
 * Une formule dont le LaTeX est invalide se rend quand même (KaTeX a un
 * mode `throwOnError:false`, produit un message d'erreur en rouge à la
 * place) — jamais de blocage de l'ouverture du fichier pour une formule
 * mal formée.
 */
import { Node } from "@tiptap/core";
export declare const InlineMath: Node<any, {
    markdown: {
        serialize(state: any, node: any): void;
        parse: {
            setup(markdownit: any): void;
            updateDOM(element: HTMLElement): void;
        };
    };
}>;
export declare const BlockMath: Node<any, {
    markdown: {
        serialize(state: any, node: any): void;
        parse: {
            setup(markdownit: any): void;
            updateDOM(element: HTMLElement): void;
        };
    };
}>;
