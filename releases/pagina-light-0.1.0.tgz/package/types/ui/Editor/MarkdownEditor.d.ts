import { type PageLayoutSettings } from "../../core/pageLayout";
import "katex/dist/katex.min.css";
import "./MarkdownEditor.css";
export interface MarkdownEditorHandle {
    getMarkdown: () => string;
    getHTML: () => string;
    focus: () => void;
    undo: () => void;
    redo: () => void;
    toggleBold: () => void;
    toggleItalic: () => void;
    toggleUnderline: () => void;
    toggleStrike: () => void;
    toggleHeading: (level: 1 | 2 | 3 | 4 | 5 | 6) => void;
    setParagraph: () => void;
    toggleBulletList: () => void;
    toggleOrderedList: () => void;
    toggleBlockquote: () => void;
    toggleCodeBlock: () => void;
    /** Code EN LIGNE (`` `code` ``) — distinct de `toggleCodeBlock` (un bloc
     * entier). */
    toggleCode: () => void;
    /** Langage de coloration syntaxique du bloc de code où se trouve le
     * curseur (aucun effet si le curseur n'est pas dans un bloc de code). */
    setCodeBlockLanguage: (language: string) => void;
    setLink: () => void;
    insertImage: (src: string, alt?: string) => void;
    insertTable: () => void;
    insertHorizontalRule: () => void;
    insertPageBreak: () => void;
    setFontFamily: (family: string) => void;
    unsetFontFamily: () => void;
    setFontSize: (size: string) => void;
    unsetFontSize: () => void;
    setColor: (color: string) => void;
    unsetColor: () => void;
    toggleHighlight: () => void;
    setTextAlign: (align: "left" | "center" | "right" | "justify") => void;
    toggleSubscript: () => void;
    toggleSuperscript: () => void;
    toggleTaskList: () => void;
    clearFormatting: () => void;
    getStats: () => EditorStats;
    /** Ouvre l'éditeur en place de l'en-tête/du pied de page (sur la première
     * page peinte), comme un clic direct dessus — pour les rendre accessibles
     * depuis un bouton du ruban, pas seulement en cliquant sur la page (pas
     * évident à trouver au premier abord). */
    editHeader: () => void;
    editFooter: () => void;
    /** Insère une variable (`{{page}}`, `{{pages}}`, `{{date}}`...) dans le
     * champ d'en-tête/pied de page en cours d'édition (ou ouvre celui de
     * l'en-tête par défaut s'il n'y en a aucun d'ouvert). */
    insertHeaderFooterVariable: (token: string) => void;
    insertTocMarker: () => void;
    generateToc: () => void;
    /** Insère une référence `[^n]` au curseur ET la définition correspondante
     * en fin de document (n = 1 + le plus grand id de note déjà utilisé). */
    insertFootnote: () => void;
    insertMermaidDiagram: () => void;
    insertInlineMath: () => void;
    insertBlockMath: () => void;
    insertEmoji: (emoji: string) => void;
}
export declare const CODE_BLOCK_LANGUAGES: string[];
export interface EditorStats {
    words: number;
    characters: number;
    pageCount: number;
    currentPage: number;
    /** Style de bloc sous le curseur — pour surligner le bon bouton dans la
     * galerie de styles du ruban (voir RibbonGroup "Styles" dans Toolbar.tsx). */
    activeBlockStyle: "paragraph" | 1 | 2 | 3 | 4 | 5 | 6;
}
interface MarkdownEditorProps {
    initialContent: string;
    onChange: (markdown: string) => void;
    onSaveRequest: () => void;
    onStats?: (stats: EditorStats) => void;
    /** Format papier, marges, en-tête/pied de page — voir pageLayout.ts. */
    layout: PageLayoutSettings;
    /** Nom de fichier affiché, disponible comme variable `{{filename}}` dans
     * l'en-tête/pied de page. */
    documentTitle: string;
    /** Édition en place de l'en-tête/pied de page (clic direct sur la page,
     * voir l'effet plus bas) — répercutée par l'appelant (App.tsx) sur le
     * store, comme pour PageSetupDialog. */
    onLayoutChange: (layout: PageLayoutSettings) => void;
    /** Niveau de zoom (1 = 100%), purement visuel. */
    zoom?: number;
    /** Ctrl+molette : proposition d'un nouveau niveau de zoom (paliers gérés par l'appelant). */
    onZoomChange?: (zoom: number) => void;
    /** Lecture seule (document figé) : aucune saisie possible, mais mise en page et défilement inchangés. */
    readOnly?: boolean;
}
export declare const MarkdownEditor: import("react").ForwardRefExoticComponent<MarkdownEditorProps & import("react").RefAttributes<MarkdownEditorHandle>>;
export {};
