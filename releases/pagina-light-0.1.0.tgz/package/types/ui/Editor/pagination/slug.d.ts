export declare function slugifyHeading(text: string): string;
/** Rend un slug unique parmi ceux déjà attribués (comme GitHub : "titre",
 * "titre-1", "titre-2"...) — deux titres avec le même texte sont fréquents
 * (ex. plusieurs "Introduction" dans un document à sections). `used` est
 * mutée : à appeler dans l'ordre du document, avec le MÊME `Set` partagé
 * pour tous les titres d'un même passage. */
export declare function uniqueHeadingSlug(text: string, used: Set<string>): string;
