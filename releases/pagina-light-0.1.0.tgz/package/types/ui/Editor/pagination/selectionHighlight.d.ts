import type { EditorView } from "@tiptap/pm/view";
export interface SelectionRect {
    left: number;
    top: number;
    width: number;
    height: number;
}
export declare function computeSelectionRects(view: EditorView, canvas: HTMLElement, from: number, to: number, zoom: number): SelectionRect[];
