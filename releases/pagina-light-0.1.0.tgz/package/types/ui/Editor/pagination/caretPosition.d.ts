import type { EditorView } from "@tiptap/pm/view";
export interface CaretScreenPosition {
    left: number;
    top: number;
    height: number;
}
/**
 * `canvas` : conteneur de la couche peinte (les boîtes de page clonées).
 * Retourne des coordonnées relatives au coin haut-gauche de `canvas`
 * (adaptées à un positionnement `position: absolute` à l'intérieur), ou
 * `null` si le bloc contenant la position n'a pas (encore) de clone peint —
 * par exemple juste après une frappe, avant le prochain repeint.
 */
export declare function computeCaretScreenPosition(view: EditorView, canvas: HTMLElement, pos: number, zoom: number): CaretScreenPosition | null;
