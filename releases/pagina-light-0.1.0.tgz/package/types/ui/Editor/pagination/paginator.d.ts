export interface PageMargins {
    top: number;
    bottom: number;
}
export interface PaginatorOptions {
    /** Hauteur totale d'une page (mm convertis en px), marges incluses. */
    pageHeight: number;
    margins: PageMargins;
}
export interface BlockPlacement {
    /** Numéro de page (1-indexé), comme dans Word. */
    pageNumber: number;
    /** Vrai si ce bloc est le premier de sa page (donc juste après une coupure). */
    startsNewPage: boolean;
    /**
     * Espace non utilisé au bas de la page PRÉCÉDENTE, seulement quand
     * `startsNewPage` est vrai suite à une coupure naturelle (pas un saut de
     * page manuel) — c'est le trou à ajouter pour que cette page précédente
     * fasse quand même une hauteur pleine, comme les autres.
     */
    previousPageLeftover: number;
}
/**
 * Machine à états qui place des blocs les uns après les autres sur des
 * pages de hauteur fixe, en gérant le cumul d'espacement façon Word (l'espace
 * "après" d'un bloc s'additionne à l'espace "avant" du suivant, il ne se
 * contente pas du plus grand des deux comme le ferait un margin-collapse CSS).
 */
export declare function createPaginator({ pageHeight, margins }: PaginatorOptions): {
    placeBlock: (height: number, spaceBefore: number, spaceAfter: number, forceBreakBefore: boolean) => BlockPlacement;
    readonly pageCount: number;
};
