import type { EditorView } from "@tiptap/pm/view";
/**
 * `zoom` : le clic est capté sur la couche peinte, qui peut être zoomée
 * (`transform: scale()`) — la distance mesurée en pixels écran doit être
 * ramenée en pixels "logiques" (ceux de l'éditeur invisible, jamais zoomé)
 * avant d'être appliquée à l'original.
 */
export declare function resolveClickPosition(view: EditorView, clickX: number, clickY: number, clonedBlock: HTMLElement, zoom: number): number | null;
/** Remonte depuis `target` jusqu'au clone de bloc de premier niveau le plus proche. */
export declare function findClonedBlock(target: EventTarget | null): HTMLElement | null;
