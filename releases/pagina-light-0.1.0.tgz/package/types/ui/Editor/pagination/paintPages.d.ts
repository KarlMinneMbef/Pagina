import type { EditorView } from "@tiptap/pm/view";
import { type HeaderFooterSettings, type HeaderFooterContext } from "../../../core/pageLayout";
export declare const SRC_POS_ATTR = "data-src-pos";
/** Porte le modèle BRUT (avec variables `{{page}}` non résolues) — permet à
 * l'édition en place (voir MarkdownEditor.tsx) de retrouver le texte à
 * éditer plutôt que sa version déjà substituée pour l'affichage. */
export declare const HEADER_TEMPLATE_ATTR = "data-header-template";
export declare const FOOTER_TEMPLATE_ATTR = "data-footer-template";
export interface PaintPagesOptions {
    pageHeightPx: number;
    marginTopPx: number;
    marginBottomPx: number;
    header: HeaderFooterSettings;
    footer: HeaderFooterSettings;
    /** Tout le contexte de substitution des variables SAUF `page`/`pages`,
     * qui dépendent de la page en cours de peinture — calculés ici. */
    context: Omit<HeaderFooterContext, "page" | "pages">;
}
export interface PaintResult {
    pageCount: number;
}
/**
 * Mesure chaque bloc de premier niveau du document (dans `view`, l'éditeur
 * invisible), décide sur quelle page il tombe (voir `paginator.ts`), et
 * reconstruit entièrement le contenu de `canvas` : une boîte `.xmd-page` par
 * page, hauteur CSS fixe, contenant des clones des blocs qui lui reviennent.
 */
export declare function paintPages(view: EditorView, canvas: HTMLElement, options: PaintPagesOptions): PaintResult;
