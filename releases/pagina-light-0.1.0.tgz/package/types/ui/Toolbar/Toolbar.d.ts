import "./Toolbar.css";
export interface ToolbarActions {
    undo: () => void;
    redo: () => void;
    toggleBold: () => void;
    toggleItalic: () => void;
    toggleUnderline: () => void;
    toggleStrike: () => void;
    toggleHeading: (level: 1 | 2 | 3 | 4 | 5 | 6) => void;
    setParagraph: () => void;
    toggleBulletList: () => void;
    toggleOrderedList: () => void;
    toggleBlockquote: () => void;
    toggleCodeBlock: () => void;
    toggleCode: () => void;
    setCodeBlockLanguage: (language: string) => void;
    setLink: () => void;
    insertImage: () => void;
    insertTable: () => void;
    insertHorizontalRule: () => void;
    insertPageBreak: () => void;
    setFontFamily: (family: string) => void;
    unsetFontFamily: () => void;
    setFontSize: (size: string) => void;
    unsetFontSize: () => void;
    setColor: (color: string) => void;
    toggleHighlight: () => void;
    setTextAlign: (align: "left" | "center" | "right" | "justify") => void;
    toggleSubscript: () => void;
    toggleSuperscript: () => void;
    toggleTaskList: () => void;
    clearFormatting: () => void;
    editHeader: () => void;
    editFooter: () => void;
    insertHeaderFooterVariable: (token: string) => void;
    insertTocMarker: () => void;
    generateToc: () => void;
    insertFootnote: () => void;
    insertMermaidDiagram: () => void;
    insertInlineMath: () => void;
    insertBlockMath: () => void;
    insertEmoji: (emoji: string) => void;
}
export declare function Toolbar({ actions, onToggleSidebar, sidebarOpen, onOpenPageSetup, onOpenHeadingStyles, activeBlockStyle, leger, }: {
    actions: ToolbarActions | null;
    onToggleSidebar: () => void;
    sidebarOpen: boolean;
    onOpenPageSetup: () => void;
    onOpenHeadingStyles: () => void;
    /** Version LÉGÈRE (intégration dans une autre application, ex. MBEF Platform) : uniquement l'onglet
     * « Accueil », sans bouton Explorateur, sans bouton Image, sans lanceurs de dialogues (mise en page,
     * styles de titres). Sans effet (false) dans Pagina elle-même. */
    leger?: boolean;
    /** Style de bloc sous le curseur — surligne le bon bouton de la galerie
     * "Styles" (voir `EditorStats.activeBlockStyle` dans MarkdownEditor.tsx). */
    activeBlockStyle?: "paragraph" | 1 | 2 | 3 | 4 | 5 | 6;
}): import("react").JSX.Element;
