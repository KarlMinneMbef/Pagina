export declare const APP_NAME = "Pagina";
export declare const APP_VERSION: string;
export declare const PUBLISHER = "Mon BE Fluides";
export declare const PUBLISHER_WEBSITE = "https://www.monbefluides.fr";
export declare const LICENSE_NOTE = "D\u00E9p\u00F4t GitHub public";
