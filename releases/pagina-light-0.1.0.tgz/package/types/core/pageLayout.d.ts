export interface HeaderFooterSettings {
    /** Texte affiché, PEUT contenir des variables `{{page}}` (voir
     * `resolveHeaderFooterText`) — vide = pas d'en-tête/pied de page du tout. */
    text: string;
    /** Hauteur réservée, en millimètres (dans la zone de marge, comme Word). */
    heightMm: number;
    /** `false` = masqué sur la première page uniquement (page de garde), le
     * reste du document garde son en-tête/pied de page normalement. */
    showOnFirstPage: boolean;
}
export interface PageLayoutSettings {
    /** Police de base du corps de texte (hors mise en forme "avancée" appliquée à la main). */
    fontFamily: string;
    /** Taille de base du corps de texte. */
    fontSize: string;
    /** Interligne (sans unité, comme CSS line-height). Word utilise ~1.08-1.15
     * par défaut selon les modèles, très loin du 1.5 "aéré" du web — trop
     * d'espace donne une densité de texte très différente d'un rendu Word. */
    lineHeight: number;
    /** Espace après chaque paragraphe, en points — équivalent du "Espacement
     * après paragraphe" de Word (~8pt par défaut), pas une marge symétrique
     * haut+bas comme un <p> HTML classique. */
    paragraphSpacingPt: number;
    /** Marges de page, en millimètres. */
    marginTopMm: number;
    marginBottomMm: number;
    marginLeftMm: number;
    marginRightMm: number;
    /** Format papier et orientation. */
    paperSize: "A4" | "Letter";
    orientation: "portrait" | "landscape";
    header: HeaderFooterSettings;
    footer: HeaderFooterSettings;
    /** Champs libres saisis à la main, disponibles comme variables `{{version}}`
     * / `{{author}}` dans l'en-tête/pied de page — pas de suivi automatique,
     * l'utilisateur les met à jour lui-même quand il le juge utile. */
    documentVersion: string;
    author: string;
    /** Style visuel + numérotation automatique par niveau de titre (1 à 6) —
     * voir `HeadingLevelStyle`. Réglable par document (pas un thème partagé
     * entre documents pour l'instant — l'utilisateur a mentionné vouloir un
     * import/export de cette config plus tard, pas encore développé). */
    headingStyles: Record<HeadingLevel, HeadingLevelStyle>;
}
export type HeadingLevel = 1 | 2 | 3 | 4 | 5 | 6;
/** Comment un niveau de titre numérote ses occurrences successives.
 * "none" = pas de numéro du tout pour ce niveau (mais son compteur continue
 * d'exister en interne pour que les niveaux enfants puissent quand même
 * numéroter "1.1", "1.2"... par rapport à lui). */
export type NumberingScheme = "none" | "decimal" | "upperRoman" | "lowerRoman" | "upperAlpha" | "lowerAlpha";
export interface HeadingLevelStyle {
    fontFamily: string;
    fontSize: string;
    color: string;
    bold: boolean;
    italic: boolean;
    numbering: NumberingScheme;
}
export declare const DEFAULT_HEADING_STYLES: Record<HeadingLevel, HeadingLevelStyle>;
/** Chiffres romains (I, II, III, IV...) — pas de zéro, `n` doit être >= 1. */
export declare function toRoman(n: number): string;
/** Numérotation alphabétique (A, B, ..., Z, AA, AB...) — comme les colonnes
 * d'un tableur, jamais de retour à vide même après 26. */
export declare function toAlpha(n: number): string;
/** Formate un compteur (>= 1) selon le schéma choisi. `numbering: "none"`
 * ne devrait normalement jamais atteindre cette fonction (filtré avant),
 * mais renvoie une chaîne vide par sécurité plutôt que de planter. */
export declare function formatCounter(n: number, scheme: NumberingScheme): string;
export declare const DEFAULT_PAGE_LAYOUT: PageLayoutSettings;
/** Dimensions "portrait" des formats papier supportés, en millimètres. */
export declare const PAPER_SIZES_MM: Record<PageLayoutSettings["paperSize"], {
    width: number;
    height: number;
}>;
/** Largeur/hauteur réelles de la page en mm, une fois l'orientation appliquée. */
export declare function resolvePageSizeMm(settings: PageLayoutSettings): {
    widthMm: number;
    heightMm: number;
};
/** Contexte de substitution des variables d'en-tête/pied de page (voir
 * `resolveHeaderFooterText`) — une valeur par variable disponible. */
export interface HeaderFooterContext {
    page: number;
    pages: number;
    date: string;
    filename: string;
    version: string;
    author: string;
}
/** Remplace les variables `{{page}}`, `{{pages}}`, `{{date}}`, `{{filename}}`,
 * `{{version}}`, `{{author}}` dans un modèle d'en-tête/pied de page par leur
 * valeur réelle pour UNE page donnée. Une variable inconnue/mal orthographiée
 * (`{{pgae}}`) est laissée telle quelle plutôt que silencieusement effacée —
 * plus facile à repérer et corriger pour l'utilisateur. */
export declare function resolveHeaderFooterText(template: string, ctx: HeaderFooterContext): string;
/** Date du jour au format JJ/MM/AAAA (pas de dépendance à une locale précise
 * du navigateur : format fixe, prévisible dans tout document imprimé). */
export declare function formatTodayForHeaderFooter(): string;
/**
 * Sépare le(s) commentaire(s) `pagina:*` (config, generator) en tête de
 * fichier du reste du contenu. Retourne toujours un `layout` complet
 * (fusionné avec les valeurs par défaut pour les champs manquants/invalides)
 * et le contenu SANS ces commentaires, prêt à être donné à l'éditeur.
 */
export declare function extractDocumentConfig(markdown: string): {
    layout: PageLayoutSettings;
    content: string;
};
/** Construit le commentaire de config à écrire en tête de fichier. */
export declare function serializeDocumentConfig(layout: PageLayoutSettings): string;
/** Construit le commentaire d'identité de l'outil (voir `appInfo.ts`),
 * réécrit à neuf à chaque sauvegarde avec la version actuelle de l'app. */
export declare function serializeGeneratorComment(): string;
/** Réassemble le contenu complet du fichier (generator + config + corps)
 * pour la sauvegarde — toujours ces deux lignes, jamais plus (fichier `.md`
 * gardé propre). */
export declare function withDocumentConfig(layout: PageLayoutSettings, content: string): string;
