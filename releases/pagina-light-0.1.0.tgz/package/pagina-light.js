import { forwardRef as e, useCallback as t, useEffect as n, useImperativeHandle as r, useMemo as i, useRef as a, useState as o } from "react";
import { EditorContent as s, useEditor as c } from "@tiptap/react";
import l from "@tiptap/starter-kit";
import u from "@tiptap/extension-image";
import { RemoveMarkStep as d, ReplaceAroundStep as f, ReplaceStep as p, Transform as m, canJoin as h, canSplit as g, joinPoint as _, liftTarget as v } from "@tiptap/pm/transform";
import { createParagraphNear as y, exitCode as b, joinBackward as x, joinDown as S, joinForward as C, joinTextblockBackward as w, joinTextblockForward as T, joinUp as E, lift as D, liftEmptyBlock as O, newlineInCode as k, selectNodeBackward as ee, selectNodeForward as te, selectParentNode as A, selectTextblockEnd as ne, selectTextblockStart as j, setBlockType as M, wrapIn as re } from "@tiptap/pm/commands";
import { AllSelection as N, NodeSelection as P, Plugin as F, PluginKey as I, Selection as L, TextSelection as R } from "@tiptap/pm/state";
import { DOMParser as ie, DOMSerializer as ae, Fragment as z, Schema as oe, Slice as se } from "@tiptap/pm/model";
import { liftListItem as ce, sinkListItem as le, wrapInList as ue } from "@tiptap/pm/schema-list";
import "@tiptap/pm/view";
import "@tiptap/pm/keymap";
import { Table as de } from "@tiptap/extension-table";
import fe from "@tiptap/extension-table-row";
import pe from "@tiptap/extension-table-cell";
import me from "@tiptap/extension-table-header";
import he from "@tiptap/extension-placeholder";
import { TextStyle as ge } from "@tiptap/extension-text-style";
import _e from "@tiptap/extension-font-family";
import ve from "@tiptap/extension-color";
import ye from "@tiptap/extension-highlight";
import be from "@tiptap/extension-text-align";
import xe from "@tiptap/extension-subscript";
import Se from "@tiptap/extension-superscript";
import Ce from "@tiptap/extension-task-list";
import we from "@tiptap/extension-task-item";
import Te from "@tiptap/extension-character-count";
import Ee from "@tiptap/extension-code-block-lowlight";
import { common as De, createLowlight as Oe } from "lowlight";
import { Markdown as ke } from "tiptap-markdown";
import { Paragraph as Ae } from "@tiptap/extension-paragraph";
import "katex/dist/katex.min.css";
import { jsx as B, jsxs as V } from "react/jsx-runtime";
//#region node_modules/@tiptap/core/dist/rolldown-runtime-D7D4PA-g.js
var je = Object.defineProperty, Me = (e, t) => {
	let n = {};
	for (var r in e) je(n, r, {
		get: e[r],
		enumerable: !0
	});
	return t || je(n, Symbol.toStringTag, { value: "Module" }), n;
};
//#endregion
//#region node_modules/@tiptap/core/dist/index.js
function Ne(e) {
	let { state: t, transaction: n } = e, { selection: r } = n, { doc: i } = n, { storedMarks: a } = n;
	return {
		...t,
		apply: t.apply.bind(t),
		applyTransaction: t.applyTransaction.bind(t),
		plugins: t.plugins,
		schema: t.schema,
		reconfigure: t.reconfigure.bind(t),
		toJSON: t.toJSON.bind(t),
		get storedMarks() {
			return a;
		},
		get selection() {
			return r;
		},
		get doc() {
			return i;
		},
		get tr() {
			return r = n.selection, i = n.doc, a = n.storedMarks, n;
		}
	};
}
var Pe = class e {
	constructor(e) {
		this.editor = e.editor, this.rawCommands = this.editor.extensionManager.commands, this.customState = e.state;
	}
	get hasCustomState() {
		return !!this.customState;
	}
	get state() {
		return this.customState || this.editor.state;
	}
	get commands() {
		let { rawCommands: e, editor: t, state: n } = this, { view: r } = t, { tr: i } = n, a = this.buildProps(i);
		return Object.fromEntries(Object.entries(e).map(([e, t]) => [e, (...e) => {
			let n = t(...e)(a);
			return !i.getMeta("preventDispatch") && !this.hasCustomState && r.dispatch(i), n;
		}]));
	}
	get chain() {
		return () => this.createChain();
	}
	get can() {
		return () => this.createCan();
	}
	createChain(e, t = !0) {
		let { rawCommands: n, editor: r, state: i } = this, { view: a } = r, o = [], s = !!e, c = e || i.tr, l = () => (!s && t && !c.getMeta("preventDispatch") && !this.hasCustomState && a.dispatch(c), o.every((e) => e === !0)), u = {
			...Object.fromEntries(Object.entries(n).map(([e, n]) => [e, (...e) => {
				let r = this.buildProps(c, t), i = n(...e)(r);
				return o.push(i), u;
			}])),
			run: l
		};
		return u;
	}
	static createFakeChain() {
		let e = new Proxy({}, { get: (t, n) => {
			if (n !== "then") return n === "run" ? () => !1 : () => e;
		} });
		return e;
	}
	createCan(e) {
		let { rawCommands: t, state: n } = this, r = e || n.tr, i = this.buildProps(r, !1);
		return {
			...Object.fromEntries(Object.entries(t).map(([e, t]) => [e, (...e) => t(...e)({
				...i,
				dispatch: void 0
			})])),
			chain: () => this.createChain(r, !1)
		};
	}
	static createFallbackCan() {
		let t = e.createFakeChain();
		return new Proxy({ chain: () => t }, { get: (e, t) => {
			if (t !== "then") return t === "chain" ? e.chain : () => !1;
		} });
	}
	buildProps(e, t = !0) {
		let { rawCommands: n, editor: r, state: i } = this, { view: a } = r, o = {
			tr: e,
			editor: r,
			view: a,
			state: Ne({
				state: i,
				transaction: e
			}),
			dispatch: t ? () => void 0 : void 0,
			chain: () => this.createChain(e, t),
			can: () => this.createCan(e),
			get commands() {
				return Object.fromEntries(Object.entries(n).map(([e, t]) => [e, (...e) => t(...e)(o)]));
			}
		};
		return o;
	}
}, Fe = () => ({ editor: e, view: t }) => (requestAnimationFrame(() => {
	if (!e.isDestroyed) {
		var n;
		t.dom.blur(), (n = window) == null || (n = n.getSelection()) == null || n.removeAllRanges();
	}
}), !0), Ie = (e = !0) => ({ commands: t }) => t.setContent("", { emitUpdate: e }), Le = () => ({ state: e, tr: t, dispatch: n }) => {
	let { selection: r } = t, { ranges: i } = r;
	return n && i.forEach(({ $from: n, $to: r }) => {
		e.doc.nodesBetween(n.pos, r.pos, (e, n) => {
			if (e.type.isText) return;
			let { doc: r, mapping: i } = t, a = r.resolve(i.map(n)), o = r.resolve(i.map(n + e.nodeSize)), s = a.blockRange(o);
			if (!s) return;
			let c = v(s);
			if (e.type.isTextblock) {
				let { defaultType: e } = a.parent.contentMatchAt(a.index());
				t.setNodeMarkup(s.start, e);
			}
			(c || c === 0) && t.lift(s, c);
		});
	}), !0;
}, Re = (e) => (t) => e(t), ze = () => ({ state: e, dispatch: t }) => y(e, t), Be = (e, t) => ({ editor: n, tr: r }) => {
	let { state: i } = n, a = i.doc.slice(e.from, e.to);
	r.deleteRange(e.from, e.to);
	let o = r.mapping.map(t);
	return r.insert(o, a.content), r.setSelection(new R(r.doc.resolve(Math.max(o - 1, 0)))), !0;
}, Ve = () => ({ tr: e, dispatch: t }) => {
	let { selection: n } = e, r = n.$anchor.node();
	if (r.content.size > 0) return !1;
	let i = e.selection.$anchor;
	for (let n = i.depth; n > 0; --n) if (i.node(n).type === r.type) {
		if (t) {
			let t = i.before(n), r = i.after(n);
			e.delete(t, r).scrollIntoView();
		}
		return !0;
	}
	return !1;
};
function H(e, t) {
	if (typeof e == "string") {
		if (!t.nodes[e]) throw Error(`There is no node type named '${e}'. Maybe you forgot to add the extension?`);
		return t.nodes[e];
	}
	return e;
}
var He = (e) => ({ tr: t, state: n, dispatch: r }) => {
	let i = H(e, n.schema), a = t.selection.$anchor;
	for (let e = a.depth; e > 0; --e) if (a.node(e).type === i) {
		if (r) {
			let n = a.before(e), r = a.after(e);
			t.delete(n, r).scrollIntoView();
		}
		return !0;
	}
	return !1;
}, Ue = (e) => ({ tr: t, dispatch: n }) => {
	let { from: r, to: i } = e;
	return n && t.delete(r, i), !0;
}, We = (e) => e.content ? /^text(\*|\+)/.test(e.content) : !1, Ge = (e, t, n) => {
	if (!e.parent.isInline || n === "left" && e.pos > e.start() || n === "right" && e.pos < e.end()) return e.pos;
	let r = t.nodes[e.parent.type.name].spec;
	return We(r) ? n === "left" ? e.start() - 1 : e.end() + 1 : e.pos;
}, Ke = (e, t, n) => ({
	from: Ge(e, n, "left"),
	to: Ge(t, n, "right")
}), qe = () => ({ state: e, dispatch: t }) => {
	if (e.selection.empty) return !1;
	if (t) {
		let n = e.tr, { ranges: r } = e.selection, i = n.steps.length;
		r.forEach((t) => {
			let r = n.mapping.slice(i), { from: a, to: o } = Ke(n.doc.resolve(r.map(t.$from.pos)), n.doc.resolve(r.map(t.$to.pos)), e.schema);
			n.deleteRange(a, o);
		}), n.selection.empty || n.setSelection(R.near(n.doc.resolve(n.selection.from))), n.scrollIntoView(), t(n);
	}
	return !0;
}, Je = () => ({ commands: e }) => e.keyboardShortcut("Enter"), Ye = () => ({ state: e, dispatch: t }) => b(e, t);
function Xe(e) {
	return Object.prototype.toString.call(e) === "[object RegExp]";
}
function Ze(e, t, n = { strict: !0 }) {
	let r = Object.keys(t);
	return !r.length || r.every((r) => n.strict ? t[r] === e[r] : Xe(t[r]) ? t[r].test(e[r]) : t[r] === e[r]);
}
function Qe(e, t, n = {}) {
	return e.find((e) => e.type === t && Ze(Object.fromEntries(Object.keys(n).map((t) => [t, e.attrs[t]])), n));
}
function $e(e, t, n = {}) {
	return !!Qe(e, t, n);
}
function et(e, t, n) {
	if (!e || !t) return;
	let r = e.parent.childAfter(e.parentOffset);
	if ((!r.node || !r.node.marks.some((e) => e.type === t)) && (r = e.parent.childBefore(e.parentOffset)), !r.node || !r.node.marks.some((e) => e.type === t)) return;
	if (!n) {
		let e = r.node.marks.find((e) => e.type === t);
		e && (n = e.attrs);
	}
	if (!Qe([...r.node.marks], t, n)) return;
	let i = r.index, a = e.start() + r.offset, o = i + 1, s = a + r.node.nodeSize;
	for (; i > 0 && $e([...e.parent.child(i - 1).marks], t, n);) --i, a -= e.parent.child(i).nodeSize;
	for (; o < e.parent.childCount && $e([...e.parent.child(o).marks], t, n);) s += e.parent.child(o).nodeSize, o += 1;
	return {
		from: a,
		to: s
	};
}
function U(e, t) {
	if (typeof e == "string") {
		if (!t.marks[e]) throw Error(`There is no mark type named '${e}'. Maybe you forgot to add the extension?`);
		return t.marks[e];
	}
	return e;
}
var tt = (e, t) => ({ tr: n, state: r, dispatch: i }) => {
	let a = U(e, r.schema), { doc: o, selection: s } = n, { $from: c, from: l, to: u } = s;
	if (i) {
		let e = et(c, a, t);
		if (e && e.from <= l && e.to >= u) {
			let t = R.create(o, e.from, e.to);
			n.setSelection(t);
		}
	}
	return !0;
}, nt = (e) => (t) => {
	let n = typeof e == "function" ? e(t) : e;
	for (let e = 0; e < n.length; e += 1) if (n[e](t)) return !0;
	return !1;
};
function rt(e) {
	return e instanceof R;
}
function W(e = 0, t = 0, n = 0) {
	return Math.min(Math.max(e, t), n);
}
function it(e, t = null) {
	if (!t) return null;
	let n = L.atStart(e), r = L.atEnd(e);
	if (t === "start" || t === !0) return n;
	if (t === "end") return r;
	let i = n.from, a = r.to;
	return t === "all" ? R.create(e, W(0, i, a), W(e.content.size, i, a)) : R.create(e, W(t, i, a), W(t, i, a));
}
function at() {
	return ["Android"].includes(navigator.platform) || /android/i.test(navigator.userAgent);
}
function G() {
	return [
		"iPad Simulator",
		"iPhone Simulator",
		"iPod Simulator",
		"iPad",
		"iPhone",
		"iPod"
	].includes(navigator.platform) || navigator.userAgent.includes("Mac") && "ontouchend" in document;
}
function ot() {
	return typeof navigator < "u" && /^((?!chrome|android).)*safari/i.test(navigator.userAgent);
}
var st = (e = null, t = {}) => ({ editor: n, view: r, tr: i, dispatch: a }) => {
	t = {
		scrollIntoView: !0,
		...t
	};
	let o = () => {
		(G() || at()) && r.dom.focus(), ot() && !G() && !at() && r.dom.focus({ preventScroll: !0 }), requestAnimationFrame(() => {
			n.isDestroyed || (r.focus(), t?.scrollIntoView && n.commands.scrollIntoView());
		});
	};
	try {
		if (r.hasFocus() && e === null || e === !1) return !0;
	} catch {
		return !1;
	}
	if (a && e === null && !rt(n.state.selection)) return o(), !0;
	let s = it(i.doc, e) || n.state.selection, c = n.state.selection.eq(s);
	return a && (c || i.setSelection(s), c && i.storedMarks && i.setStoredMarks(i.storedMarks), o()), !0;
}, ct = (e, t) => (n) => e.every((e, r) => t(e, {
	...n,
	index: r
})), lt = (e, t) => ({ tr: n, commands: r }) => r.insertContentAt({
	from: n.selection.from,
	to: n.selection.to
}, e, t), ut = (e) => {
	let t = e.childNodes;
	for (let n = t.length - 1; n >= 0; --n) {
		let r = t[n];
		r.nodeType === 3 && r.nodeValue && /^(\n\s\s|\n)$/.test(r.nodeValue) ? e.removeChild(r) : r.nodeType === 1 && ut(r);
	}
	return e;
};
function K(e) {
	if (typeof window > "u") throw Error("[tiptap error]: there is no window object available, so this function cannot be used");
	let t = `<body>${e}</body>`, n = new window.DOMParser().parseFromString(t, "text/html").body;
	return ut(n);
}
function dt(e) {
	return typeof e?.nodesBetween == "function";
}
function q(e, t, n) {
	if (dt(e)) return e;
	let r = typeof e == "object" && !!e;
	n = {
		slice: !0,
		parseOptions: {},
		...n
	};
	let i = typeof e == "string";
	if (r) try {
		if (Array.isArray(e) && e.length > 0) return z.fromArray(e.map((e) => t.nodeFromJSON(e)));
		let r = t.nodeFromJSON(e);
		return n.errorOnInvalidContent && r.check(), r;
	} catch (r) {
		if (n.errorOnInvalidContent) throw Error("[tiptap error]: Invalid JSON content", { cause: r });
		return console.warn("[tiptap warn]: Invalid content.", "Passed value:", e, "Error:", r), q("", t, n);
	}
	if (i) {
		if (n.errorOnInvalidContent) {
			let r = !1, i = "", a = new oe({
				topNode: t.spec.topNode,
				marks: t.spec.marks,
				nodes: t.spec.nodes.append({ __tiptap__private__unknown__catch__all__node: {
					content: "inline*",
					group: "block",
					parseDOM: [{
						tag: "*",
						getAttrs: (e) => (r = !0, i = typeof e == "string" ? e : e.outerHTML, null)
					}]
				} })
			});
			if (n.slice ? ie.fromSchema(a).parseSlice(K(e), n.parseOptions) : ie.fromSchema(a).parse(K(e), n.parseOptions), n.errorOnInvalidContent && r) throw Error("[tiptap error]: Invalid HTML content", { cause: /* @__PURE__ */ Error(`Invalid element found: ${i}`) });
		}
		let r = ie.fromSchema(t);
		return n.slice ? r.parseSlice(K(e), n.parseOptions).content : r.parse(K(e), n.parseOptions);
	}
	return q("", t, n);
}
function ft(e) {
	return !("type" in e);
}
function pt(e, t, n) {
	let r = e.steps.length - 1;
	if (r < t) return;
	let i = e.steps[r];
	if (!(i instanceof p || i instanceof f)) return;
	let a = e.mapping.maps[r], o = 0;
	a.forEach((e, t, n, r) => {
		o === 0 && (o = r);
	}), e.setSelection(L.near(e.doc.resolve(o), n));
}
var mt = (e, t, n) => ({ tr: r, dispatch: i, editor: a }) => {
	if (i) {
		n = {
			parseOptions: a.options.parseOptions,
			updateSelection: !0,
			applyInputRules: !1,
			applyPasteRules: !1,
			...n
		};
		let i, o = (e) => {
			a.emit("contentError", {
				editor: a,
				error: e,
				disableCollaboration: () => {
					"collaboration" in a.storage && typeof a.storage.collaboration == "object" && a.storage.collaboration && (a.storage.collaboration.isDisabled = !0);
				}
			});
		}, s = {
			preserveWhitespace: "full",
			...n.parseOptions
		};
		if (!n.errorOnInvalidContent && !a.options.enableContentCheck && a.options.emitContentError) try {
			q(t, a.schema, {
				parseOptions: s,
				errorOnInvalidContent: !0
			});
		} catch (e) {
			o(e);
		}
		try {
			i = q(t, a.schema, {
				parseOptions: s,
				errorOnInvalidContent: n.errorOnInvalidContent ?? a.options.enableContentCheck
			});
		} catch (e) {
			return o(e), !1;
		}
		let { from: c, to: l } = typeof e == "number" ? {
			from: e,
			to: e
		} : {
			from: e.from,
			to: e.to
		}, u = !0, d = !0, f = ft(i) ? i.content : [i];
		if (f.forEach((e) => {
			e.check(), u = u ? e.isText && e.marks.length === 0 : !1, d = d ? e.isBlock : !1;
		}), c === l && d) {
			let { parent: e } = r.doc.resolve(c);
			e.isTextblock && !e.type.spec.code && !e.childCount && (--c, l += 1);
		}
		let p;
		if (u) p = Array.isArray(t) ? t.map((e) => e.text || "").join("") : dt(t) ? f.map((e) => e.text ?? "").join("") : typeof t == "object" && t && t.text ? t.text : t, r.insertText(p, c, l);
		else {
			p = z.from(f);
			let e = r.doc.resolve(c), t = e.node(), n = e.parentOffset === 0, i = t.isText || t.isTextblock, a = t.content.size > 0;
			n && i && a && d && (c = Math.max(0, c - 1)), r.replaceWith(c, l, f);
		}
		n.updateSelection && pt(r, r.steps.length - 1, -1), n.applyInputRules && r.setMeta("applyInputRules", {
			from: c,
			text: p
		}), n.applyPasteRules && r.setMeta("applyPasteRules", {
			from: c,
			text: p
		});
	}
	return !0;
};
function ht(e) {
	for (let t = 0; t < e.edgeCount; t += 1) {
		let { type: n } = e.edge(t);
		if (n.isTextblock && !n.hasRequiredAttrs()) return n;
	}
	return null;
}
var gt = (e = {}) => ({ tr: t, dispatch: n, editor: r }) => {
	let { pos: i, attrs: a, content: o, updateSelection: s = !0 } = e, c;
	c = typeof i == "number" ? t.doc.resolve(i) : i || t.selection.$from;
	let l = ht(c.parent.contentMatchAt(c.index()));
	if (!l) return !1;
	let u = Object.keys(l.spec.attrs || {}), d = a ? Object.fromEntries(Object.entries(a).filter(([e]) => u.includes(e))) : {}, f;
	if (o) {
		let e = q(o, r.schema);
		f = l.createAndFill(d, e);
	} else f = l.createAndFill(d);
	return f ? (n && (t.insert(c.pos, f), s && pt(t, t.steps.length - 1, -1)), !0) : !1;
}, _t = () => ({ state: e, dispatch: t }) => E(e, t), vt = () => ({ state: e, dispatch: t }) => S(e, t), yt = () => ({ state: e, dispatch: t }) => x(e, t), bt = () => ({ state: e, dispatch: t }) => C(e, t), xt = () => ({ state: e, dispatch: t, tr: n }) => {
	try {
		let r = _(e.doc, e.selection.$from.pos, -1);
		return r != null && (n.join(r, 2), t && t(n), !0);
	} catch {
		return !1;
	}
}, St = () => ({ state: e, dispatch: t, tr: n }) => {
	try {
		let r = _(e.doc, e.selection.$from.pos, 1);
		return r != null && (n.join(r, 2), t && t(n), !0);
	} catch {
		return !1;
	}
}, Ct = () => ({ state: e, dispatch: t }) => w(e, t), wt = () => ({ state: e, dispatch: t }) => T(e, t);
function Tt() {
	return typeof navigator < "u" && /Mac/.test(navigator.platform);
}
function Et(e) {
	let t = e.split(/-(?!$)/), n = t[t.length - 1];
	n === "Space" && (n = " ");
	let r, i, a, o;
	for (let e = 0; e < t.length - 1; e += 1) {
		let n = t[e];
		if (/^(cmd|meta|m)$/i.test(n)) o = !0;
		else if (/^a(lt)?$/i.test(n)) r = !0;
		else if (/^(c|ctrl|control)$/i.test(n)) i = !0;
		else if (/^s(hift)?$/i.test(n)) a = !0;
		else if (/^mod$/i.test(n)) G() || Tt() ? o = !0 : i = !0;
		else throw Error(`Unrecognized modifier name: ${n}`);
	}
	return r && (n = `Alt-${n}`), i && (n = `Ctrl-${n}`), o && (n = `Meta-${n}`), a && (n = `Shift-${n}`), n;
}
var Dt = (e) => ({ editor: t, view: n, tr: r, dispatch: i }) => {
	let a = Et(e).split(/-(?!$)/), o = a.find((e) => ![
		"Alt",
		"Ctrl",
		"Meta",
		"Shift"
	].includes(e)), s = new KeyboardEvent("keydown", {
		key: o === "Space" ? " " : o,
		altKey: a.includes("Alt"),
		ctrlKey: a.includes("Ctrl"),
		metaKey: a.includes("Meta"),
		shiftKey: a.includes("Shift"),
		bubbles: !0,
		cancelable: !0
	});
	return t.captureTransaction(() => {
		n.someProp("handleKeyDown", (e) => e(n, s));
	})?.steps.forEach((e) => {
		let t = e.map(r.mapping);
		t && i && r.maybeStep(t);
	}), !0;
};
function Ot(e, t, n = {}) {
	let { from: r, to: i, empty: a } = e.selection, o = t ? H(t, e.schema) : null, s = [];
	e.doc.nodesBetween(r, i, (e, t) => {
		if (e.isText) return;
		let n = Math.max(r, t), a = Math.min(i, t + e.nodeSize);
		s.push({
			node: e,
			from: n,
			to: a
		});
	});
	let c = i - r, l = s.filter((e) => !o || o.name === e.node.type.name).filter((e) => Ze(e.node.attrs, n, { strict: !1 }));
	return a ? !!l.length : l.reduce((e, t) => e + t.to - t.from, 0) >= c;
}
var kt = (e, t = {}) => ({ state: n, dispatch: r }) => Ot(n, H(e, n.schema), t) ? D(n, r) : !1, At = () => ({ state: e, dispatch: t }) => O(e, t), jt = (e) => ({ state: t, dispatch: n }) => {
	let r = H(e, t.schema);
	return ce(r)(t, n);
}, Mt = () => ({ state: e, dispatch: t }) => k(e, t);
function Nt(e, t) {
	return t.nodes[e] ? "node" : t.marks[e] ? "mark" : null;
}
function Pt(e, t) {
	let n = typeof t == "string" ? [t] : t;
	return Object.keys(e).reduce((t, r) => (n.includes(r) || (t[r] = e[r]), t), {});
}
var Ft = (e, t) => ({ tr: n, state: r, dispatch: i }) => {
	let a = null, o = null, s = Nt(typeof e == "string" ? e : e.name, r.schema);
	if (!s) return !1;
	s === "node" && (a = H(e, r.schema)), s === "mark" && (o = U(e, r.schema));
	let c = !1;
	return n.selection.ranges.forEach((e) => {
		r.doc.nodesBetween(e.$from.pos, e.$to.pos, (e, r) => {
			a && a === e.type && (c = !0, i && n.setNodeMarkup(r, void 0, Pt(e.attrs, t))), o && e.marks.length && e.marks.forEach((a) => {
				o === a.type && (c = !0, i && n.addMark(r, r + e.nodeSize, o.create(Pt(a.attrs, t))));
			});
		});
	}), c;
}, It = () => ({ tr: e, dispatch: t }) => (t && e.scrollIntoView(), !0), Lt = () => ({ tr: e, dispatch: t }) => {
	if (t) {
		let t = new N(e.doc);
		e.setSelection(t);
	}
	return !0;
}, Rt = () => ({ state: e, dispatch: t }) => ee(e, t), zt = () => ({ state: e, dispatch: t }) => te(e, t), Bt = () => ({ state: e, dispatch: t }) => A(e, t), Vt = () => ({ state: e, dispatch: t }) => ne(e, t), Ht = () => ({ state: e, dispatch: t }) => j(e, t);
function Ut(e, t, n = {}, r = {}) {
	return q(e, t, {
		slice: !1,
		parseOptions: n,
		errorOnInvalidContent: r.errorOnInvalidContent
	});
}
var Wt = (e, { errorOnInvalidContent: t, emitUpdate: n = !0, parseOptions: r = {} } = {}) => ({ editor: i, tr: a, dispatch: o, commands: s }) => {
	let { doc: c } = a;
	if (r.preserveWhitespace !== "full") {
		let s = Ut(e, i.schema, r, { errorOnInvalidContent: t ?? i.options.enableContentCheck });
		if (o) {
			let e = ft(s) ? s.content : [s];
			a.replaceWith(0, c.content.size, e).setMeta("preventUpdate", !n);
		}
		return !0;
	}
	return o && a.setMeta("preventUpdate", !n), s.insertContentAt({
		from: 0,
		to: c.content.size
	}, e, {
		parseOptions: r,
		errorOnInvalidContent: t ?? i.options.enableContentCheck
	});
};
function Gt(e, t) {
	let n = U(t, e.schema), { from: r, to: i, empty: a } = e.selection, o = [];
	a ? (e.storedMarks && o.push(...e.storedMarks), o.push(...e.selection.$head.marks())) : e.doc.nodesBetween(r, i, (e) => {
		o.push(...e.marks);
	});
	let s = o.find((e) => e.type.name === n.name);
	return s ? { ...s.attrs } : {};
}
function Kt(e, t) {
	let n = new m(e);
	return t.forEach((e) => {
		e.steps.forEach((e) => {
			n.step(e);
		});
	}), n;
}
function qt(e, t) {
	for (let n = e.depth; n > 0; --n) {
		let r = e.node(n);
		if (t(r)) return {
			pos: n > 0 ? e.before(n) : 0,
			start: e.start(n),
			depth: n,
			node: r
		};
	}
}
function Jt(e) {
	return (t) => qt(t.$from, e);
}
function J(e, t, n) {
	return e.config[t] === void 0 && e.parent ? J(e.parent, t, n) : typeof e.config[t] == "function" ? e.config[t].bind({
		...n,
		parent: e.parent ? J(e.parent, t, n) : null
	}) : e.config[t];
}
function Yt(e, t) {
	let n = ae.fromSchema(t).serializeFragment(e), r = document.implementation.createHTMLDocument().createElement("div");
	return r.appendChild(n), r.innerHTML;
}
function Xt(e) {
	return typeof e == "function";
}
function Zt(e, t = void 0, ...n) {
	return Xt(e) ? t ? e.bind(t)(...n) : e(...n) : e;
}
function Qt(e) {
	return {
		baseExtensions: e.filter((e) => e.type === "extension"),
		nodeExtensions: e.filter((e) => e.type === "node"),
		markExtensions: e.filter((e) => e.type === "mark")
	};
}
function $t(e) {
	let t = [], n = "", r = !1, i = !1, a = 0, o = e.length;
	for (let s = 0; s < o; s += 1) {
		let o = e[s];
		if (o === "'" && !i) {
			r = !r, n += o;
			continue;
		}
		if (o === "\"" && !r) {
			i = !i, n += o;
			continue;
		}
		if (!r && !i) {
			if (o === "(") {
				a += 1, n += o;
				continue;
			}
			if (o === ")" && a > 0) {
				--a, n += o;
				continue;
			}
			if (o === ";" && a === 0) {
				t.push(n), n = "";
				continue;
			}
		}
		n += o;
	}
	return n && t.push(n), t;
}
function en(e) {
	let t = [], n = $t(e || ""), r = n.length;
	for (let e = 0; e < r; e += 1) {
		let r = n[e], i = r.indexOf(":");
		if (i === -1) continue;
		let a = r.slice(0, i).trim(), o = r.slice(i + 1).trim();
		a && o && t.push([a, o]);
	}
	return t;
}
function tn(...e) {
	return e.filter((e) => !!e).reduce((e, t) => {
		let n = { ...e };
		return Object.entries(t).forEach(([e, t]) => {
			if (e === "__proto__") {
				Object.defineProperty(n, e, {
					configurable: !0,
					enumerable: !0,
					value: t,
					writable: !0
				});
				return;
			}
			if (!n[e]) {
				n[e] = t;
				return;
			}
			if (e === "class") {
				let r = t ? String(t).split(" ") : [], i = n[e] ? n[e].split(" ") : [], a = r.filter((e) => !i.includes(e));
				n[e] = [...i, ...a].join(" ");
			} else if (e === "style") {
				let r = new Map([...en(n[e]), ...en(t)]);
				n[e] = Array.from(r.entries()).map(([e, t]) => `${e}: ${t}`).join("; ");
			} else n[e] = t;
		}), n;
	}, {});
}
function nn(e, t, n) {
	let { from: r, to: i } = t, { blockSeparator: a = "\n\n", textSerializers: o = {} } = n || {}, s = "";
	return e.nodesBetween(r, i, (e, n, c, l) => {
		e.isBlock && n > r && (s += a);
		let u = o?.[e.type.name];
		if (u) return c && (s += u({
			node: e,
			pos: n,
			parent: c,
			index: l,
			range: t
		})), !1;
		if (e.isText) {
			var d;
			s += e == null || (d = e.text) == null ? void 0 : d.slice(Math.max(r, n) - n, i - n);
		}
	}), s;
}
function rn(e) {
	return Object.fromEntries(Object.entries(e.nodes).filter(([, e]) => e.spec.toText).map(([e, t]) => [e, t.spec.toText]));
}
function an(e, t = JSON.stringify) {
	let n = {};
	return e.filter((e) => {
		let r = t(e);
		return Object.prototype.hasOwnProperty.call(n, r) ? !1 : n[r] = !0;
	});
}
function on(e) {
	let t = an(e);
	return t.length === 1 ? t : t.filter((e, n) => !t.filter((e, t) => t !== n).some((t) => e.oldRange.from >= t.oldRange.from && e.oldRange.to <= t.oldRange.to && e.newRange.from >= t.newRange.from && e.newRange.to <= t.newRange.to));
}
function sn(e) {
	let { mapping: t, steps: n } = e, r = [];
	return t.maps.forEach((e, i) => {
		let a = [];
		if (e.ranges.length) e.forEach((e, t) => {
			a.push({
				from: e,
				to: t
			});
		});
		else {
			let { from: e, to: t } = n[i];
			if (e === void 0 || t === void 0) return;
			a.push({
				from: e,
				to: t
			});
		}
		a.forEach(({ from: e, to: n }) => {
			let a = t.slice(i).map(e, -1), o = t.slice(i).map(n), s = t.invert().map(a, -1), c = t.invert().map(o);
			r.push({
				oldRange: {
					from: s,
					to: c
				},
				newRange: {
					from: a,
					to: o
				}
			});
		});
	}), on(r);
}
function cn(e, t, n) {
	return Object.fromEntries(Object.entries(n).filter(([n]) => {
		let r = e.find((e) => e.type === t && e.name === n);
		return r ? r.attribute.keepOnSplit : !1;
	}));
}
function ln(e, t, n = {}) {
	let { empty: r, ranges: i } = e.selection, a = t ? U(t, e.schema) : null;
	if (r) return !!(e.storedMarks || e.selection.$from.marks()).filter((e) => !a || a.name === e.type.name).find((e) => Ze(e.attrs, n, { strict: !1 }));
	let o = 0, s = [];
	if (i.forEach(({ $from: t, $to: n }) => {
		let r = t.pos, i = n.pos;
		e.doc.nodesBetween(r, i, (e, t) => {
			if (a && e.inlineContent && !e.type.allowsMarkType(a)) return !1;
			if (!e.isText && !e.marks.length) return;
			let n = Math.max(r, t), c = Math.min(i, t + e.nodeSize), l = c - n;
			o += l, s.push(...e.marks.map((e) => ({
				mark: e,
				from: n,
				to: c
			})));
		});
	}), o === 0) return !1;
	let c = s.filter((e) => !a || a.name === e.mark.type.name).filter((e) => Ze(e.mark.attrs, n, { strict: !1 })).reduce((e, t) => e + t.to - t.from, 0), l = s.filter((e) => !a || e.mark.type !== a && e.mark.type.excludes(a)).reduce((e, t) => e + t.to - t.from, 0);
	return (c > 0 ? c + l : c) >= o;
}
function un(e, t) {
	let { nodeExtensions: n } = Qt(t), r = n.find((t) => t.name === e);
	if (!r) return !1;
	let i = Zt(J(r, "group", {
		name: r.name,
		options: r.options,
		storage: r.storage
	}));
	return typeof i == "string" && i.split(" ").includes("list");
}
function dn(e, { checkChildren: t = !0, ignoreWhitespace: n = !1 } = {}) {
	if (n) {
		if (e.type.name === "hardBreak") return !0;
		if (e.isText) return !/\S/.test(e.text ?? "");
	}
	if (e.isText) return !e.text;
	if (e.isAtom || e.isLeaf) return !1;
	if (e.content.childCount === 0) return !0;
	if (t) {
		let r = !0;
		return e.content.forEach((e) => {
			r !== !1 && (dn(e, {
				ignoreWhitespace: n,
				checkChildren: t
			}) || (r = !1));
		}), r;
	}
	return !1;
}
function fn(e, t, n) {
	let { selection: r } = t, i = null;
	if (rt(r) && (i = r.$cursor), i) {
		let t = e.storedMarks ?? i.marks();
		return i.parent.type.allowsMarkType(n) && (!!n.isInSet(t) || !t.some((e) => e.type.excludes(n)));
	}
	let { ranges: a } = r;
	return a.some(({ $from: t, $to: r }) => {
		let i = t.depth === 0 && e.doc.inlineContent && e.doc.type.allowsMarkType(n);
		return e.doc.nodesBetween(t.pos, r.pos, (e, t, r) => {
			if (i) return !1;
			if (e.isInline) {
				let t = !r || r.type.allowsMarkType(n), a = !!n.isInSet(e.marks) || !e.marks.some((e) => e.type.excludes(n));
				i = t && a;
			}
			return !i;
		}), i;
	});
}
var pn = (e, t = {}) => ({ tr: n, state: r, dispatch: i }) => {
	let { selection: a } = n, { empty: o, ranges: s } = a, c = U(e, r.schema);
	if (i) {
		if (o) {
			let e = Gt(r, c);
			n.addStoredMark(c.create({
				...e,
				...t
			}));
		} else s.forEach((e) => {
			let i = e.$from.pos, a = e.$to.pos;
			r.doc.nodesBetween(i, a, (e, r) => {
				let o = Math.max(r, i), s = Math.min(r + e.nodeSize, a);
				e.marks.find((e) => e.type === c) ? e.marks.forEach((e) => {
					c === e.type && n.addMark(o, s, c.create({
						...e.attrs,
						...t
					}));
				}) : n.addMark(o, s, c.create(t));
			});
		});
	}
	return fn(r, n, c);
}, mn = (e, t) => ({ tr: n }) => (n.setMeta(e, t), !0), hn = (e, t = {}) => ({ state: n, dispatch: r, chain: i }) => {
	let a = H(e, n.schema), o;
	return n.selection.$anchor.sameParent(n.selection.$head) && (o = n.selection.$anchor.parent.attrs), a.isTextblock ? i().command(({ commands: e }) => M(a, {
		...o,
		...t
	})(n) ? !0 : e.clearNodes()).command(({ state: e }) => M(a, {
		...o,
		...t
	})(e, r)).run() : (console.warn("[tiptap warn]: Currently \"setNode()\" only supports text block nodes."), !1);
}, gn = (e) => ({ tr: t, dispatch: n }) => {
	if (n) {
		let { doc: n } = t, r = W(e, 0, n.content.size), i = P.create(n, r);
		t.setSelection(i);
	}
	return !0;
}, _n = (e, t) => ({ tr: n, state: r, dispatch: i }) => {
	let { selection: a } = r, o, s;
	return typeof t == "number" ? (o = t, s = t) : t && "from" in t && "to" in t ? (o = t.from, s = t.to) : (o = a.from, s = a.to), i && n.doc.nodesBetween(o, s, (t, r) => {
		t.isText || n.setNodeMarkup(r, void 0, {
			...t.attrs,
			dir: e
		});
	}), !0;
}, vn = (e) => ({ tr: t, dispatch: n }) => {
	if (n) {
		let { doc: n } = t, { from: r, to: i } = typeof e == "number" ? {
			from: e,
			to: e
		} : e, a = R.atStart(n).from, o = R.atEnd(n).to, s = W(r, a, o), c = W(i, a, o), l = R.create(n, s, c);
		t.setSelection(l);
	}
	return !0;
}, yn = (e) => ({ state: t, dispatch: n }) => {
	let r = H(e, t.schema);
	return le(r)(t, n);
};
function bn(e, t) {
	let n = e.storedMarks || e.selection.$to.parentOffset && e.selection.$from.marks();
	if (n) {
		let r = n.filter((e) => t?.includes(e.type.name));
		e.tr.ensureMarks(r);
	}
}
var xn = ({ keepMarks: e = !0 } = {}) => ({ tr: t, state: n, dispatch: r, editor: i }) => {
	let { selection: a, doc: o } = t, { $from: s, $to: c } = a, l = i.extensionManager.attributes, u = cn(l, s.node().type.name, s.node().attrs);
	if (a instanceof P && a.node.isBlock) return !s.parentOffset || !g(o, s.pos) ? !1 : (r && (e && bn(n, i.extensionManager.splittableMarks), t.split(s.pos).scrollIntoView()), !0);
	if (!s.parent.isBlock) return !1;
	let d = c.parentOffset === c.parent.content.size, f = s.depth === 0 ? void 0 : ht(s.node(-1).contentMatchAt(s.indexAfter(-1))), p = d && f ? [{
		type: f,
		attrs: u
	}] : void 0, m = g(t.doc, t.mapping.map(s.pos), 1, p);
	if (!p && !m && g(t.doc, t.mapping.map(s.pos), 1, f ? [{ type: f }] : void 0) && (m = !0, p = f ? [{
		type: f,
		attrs: u
	}] : void 0), r) {
		if (m && (a instanceof R && t.deleteSelection(), t.split(t.mapping.map(s.pos), 1, p), f && !d && !s.parentOffset && s.parent.type !== f)) {
			let e = t.mapping.map(s.before()), n = t.doc.resolve(e);
			s.node(-1).canReplaceWith(n.index(), n.index() + 1, f) && t.setNodeMarkup(t.mapping.map(s.before()), f);
		}
		e && bn(n, i.extensionManager.splittableMarks), t.scrollIntoView();
	}
	return m;
}, Sn = (e, t = {}) => ({ tr: n, state: r, dispatch: i, editor: a }) => {
	let o = H(e, r.schema), { $from: s, $to: c } = r.selection, l = r.selection.node;
	if (l && l.isBlock || s.depth < 2 || !s.sameParent(c)) return !1;
	let u = s.node(-1);
	if (u.type !== o) return !1;
	let d = a.extensionManager.attributes;
	if (s.parent.content.size === 0 && s.node(-1).childCount === s.indexAfter(-1)) {
		if (s.depth === 2 || s.node(-3).type !== o || s.index(-2) !== s.node(-2).childCount - 1) return !1;
		if (i) {
			let e = z.empty, r = s.index(-1) ? 1 : s.index(-2) ? 2 : 3;
			for (let t = s.depth - r; t >= s.depth - 3; --t) e = z.from(s.node(t).copy(e));
			let i = s.indexAfter(-1) < s.node(-2).childCount ? 1 : s.indexAfter(-2) < s.node(-3).childCount ? 2 : 3, a = {
				...cn(d, s.node().type.name, s.node().attrs),
				...t
			}, c = o.contentMatch.defaultType?.createAndFill(a) || void 0;
			e = e.append(z.from(o.createAndFill(null, c) || void 0));
			let l = s.before(s.depth - (r - 1));
			n.replace(l, s.after(-i), new se(e, 4 - r, 0));
			let u = -1;
			n.doc.nodesBetween(l, n.doc.content.size, (e, t) => {
				if (u > -1) return !1;
				e.isTextblock && e.content.size === 0 && (u = t + 1);
			}), u > -1 && n.setSelection(R.near(n.doc.resolve(u))), n.scrollIntoView();
		}
		return !0;
	}
	let f = c.pos === s.end() ? u.contentMatchAt(0).defaultType : null, p = {
		...cn(d, u.type.name, u.attrs),
		...t
	}, m = {
		...cn(d, s.node().type.name, s.node().attrs),
		...t
	};
	n.delete(s.pos, c.pos);
	let h = f ? [{
		type: o,
		attrs: p
	}, {
		type: f,
		attrs: m
	}] : [{
		type: o,
		attrs: p
	}];
	if (!g(n.doc, s.pos, 2)) return !1;
	if (i) {
		let { selection: e, storedMarks: t } = r, { splittableMarks: o } = a.extensionManager, c = t || e.$to.parentOffset && e.$from.marks();
		if (n.split(s.pos, 2, h).scrollIntoView(), !c || !i) return !0;
		let l = c.filter((e) => o.includes(e.type.name));
		n.ensureMarks(l);
	}
	return !0;
};
function Cn(e) {
	return !e || e === "1" ? null : e;
}
function wn(e, t) {
	return Cn(e) === Cn(t);
}
var Tn = (e, t) => {
	let n = Jt((e) => e.type === t)(e.selection);
	if (!n) return !0;
	let r = e.doc.resolve(Math.max(0, n.pos - 1)).before(n.depth);
	if (r === void 0) return !0;
	let i = e.doc.nodeAt(r);
	return !(n.node.type === i?.type && h(e.doc, n.pos)) || !wn(n.node.attrs.type, i?.attrs.type) || e.join(n.pos), !0;
}, En = (e, t) => {
	let n = Jt((e) => e.type === t)(e.selection);
	if (!n) return !0;
	let r = e.doc.resolve(n.start).after(n.depth);
	if (r === void 0) return !0;
	let i = e.doc.nodeAt(r);
	return !(n.node.type === i?.type && h(e.doc, r)) || !wn(n.node.attrs.type, i?.attrs.type) || e.join(r), !0;
};
function Dn(e) {
	let t = e.doc, n = t.firstChild;
	if (!n) return null;
	let r = t.resolve(1), i = t.resolve(n.nodeSize - 1);
	return R.between(r, i);
}
var On = (e, t, n, r = {}) => ({ editor: i, tr: a, state: o, dispatch: s, chain: c, commands: l, can: u }) => {
	let { extensions: d, splittableMarks: f } = i.extensionManager, p = H(e, o.schema), m = H(t, o.schema), { selection: h, storedMarks: g } = o, { $from: _, $to: v } = h, y = _.blockRange(v), b = g || h.$to.parentOffset && h.$from.marks();
	if (!y) return !1;
	let x = Jt((e) => un(e.type.name, d))(h), S = h.from === 0 && h.to === o.doc.content.size, C = o.doc.content.content, w = C.length === 1 ? C[0] : null, T = S && w && un(w.type.name, d) ? {
		node: w,
		pos: 0,
		depth: 0
	} : null, E = x ?? T, D = !!x && y.depth >= 1 && y.depth - x.depth <= 1, O = !!T;
	if ((D || O) && E) {
		if (E.node.type === p) return S && O ? c().command(({ tr: e, dispatch: t }) => {
			let n = Dn(e);
			return n ? (e.setSelection(n), t && t(e), !0) : !1;
		}).liftListItem(m).run() : l.liftListItem(m);
		if (un(E.node.type.name, d) && p.validContent(E.node.content)) return c().command(() => (a.setNodeMarkup(E.pos, p), !0)).command(() => Tn(a, p)).command(() => En(a, p)).run();
	}
	return !n || !b || !s ? c().command(() => u().wrapInList(p, r) ? !0 : l.clearNodes()).wrapInList(p, r).command(() => Tn(a, p)).command(() => En(a, p)).run() : c().command(() => {
		let e = u().wrapInList(p, r), t = b.filter((e) => f.includes(e.type.name));
		return a.ensureMarks(t), e ? !0 : l.clearNodes();
	}).wrapInList(p, r).command(() => Tn(a, p)).command(() => En(a, p)).run();
}, kn = (e, t = {}, n = {}) => ({ state: r, commands: i }) => {
	let { extendEmptyMarkRange: a = !1 } = n, o = U(e, r.schema);
	return ln(r, o, t) ? i.unsetMark(o, { extendEmptyMarkRange: a }) : i.setMark(o, t);
}, An = (e, t, n = {}) => ({ state: r, commands: i }) => {
	let a = H(e, r.schema), o = H(t, r.schema), s = Ot(r, a, n), c;
	return r.selection.$anchor.sameParent(r.selection.$head) && (c = r.selection.$anchor.parent.attrs), s ? i.setNode(o, c) : i.setNode(a, {
		...c,
		...n
	});
}, jn = (e, t = {}) => ({ state: n, commands: r }) => {
	let i = H(e, n.schema);
	return Ot(n, i, t) ? r.lift(i) : r.wrapIn(i, t);
}, Mn = () => ({ state: e, dispatch: t }) => {
	let n = e.plugins;
	for (let r = 0; r < n.length; r += 1) {
		let i = n[r], a;
		if (i.spec.isInputRules && (a = i.getState(e))) {
			if (t) {
				let t = e.tr, n = a.transform;
				for (let e = n.steps.length - 1; e >= 0; --e) t.step(n.steps[e].invert(n.docs[e]));
				if (a.text) {
					let n = t.doc.resolve(a.from).marks();
					t.replaceWith(a.from, a.to, e.schema.text(a.text, n));
				} else t.delete(a.from, a.to);
			}
			return !0;
		}
	}
	return !1;
}, Nn = (e = {}) => ({ tr: t, dispatch: n, editor: r }) => {
	let { ignoreClearable: i = !1 } = e, { selection: a } = t, { empty: o, ranges: s } = a;
	if (o) return !0;
	let { nonClearableMarks: c } = r.extensionManager;
	if (n) {
		let e = Object.values(r.schema.marks).filter((e) => i || !c.includes(e.name));
		s.forEach((n) => {
			for (let r of e) t.removeMark(n.$from.pos, n.$to.pos, r);
		});
	}
	return !0;
}, Pn = (e, t = {}) => ({ tr: n, state: r, dispatch: i }) => {
	let { extendEmptyMarkRange: a = !1 } = t, { selection: o } = n, s = U(e, r.schema), { $from: c, empty: l, ranges: u } = o;
	if (!i) return !0;
	if (l && a) {
		let { from: e, to: t } = o, r = et(c, s, c.marks().find((e) => e.type === s)?.attrs);
		r && (e = r.from, t = r.to), n.removeMark(e, t, s);
	} else u.forEach((e) => {
		n.removeMark(e.$from.pos, e.$to.pos, s);
	});
	return n.removeStoredMark(s), !0;
}, Fn = (e) => ({ tr: t, state: n, dispatch: r }) => {
	let { selection: i } = n, a, o;
	return typeof e == "number" ? (a = e, o = e) : e && "from" in e && "to" in e ? (a = e.from, o = e.to) : (a = i.from, o = i.to), r && t.doc.nodesBetween(a, o, (e, n) => {
		if (e.isText) return;
		let r = { ...e.attrs };
		delete r.dir, t.setNodeMarkup(n, void 0, r);
	}), !0;
}, In = (e, t = {}) => ({ tr: n, state: r, dispatch: i }) => {
	let a = null, o = null, s = Nt(typeof e == "string" ? e : e.name, r.schema);
	if (!s) return !1;
	s === "node" && (a = H(e, r.schema)), s === "mark" && (o = U(e, r.schema));
	let c = !1;
	return n.selection.ranges.forEach((e) => {
		let s = e.$from.pos, l = e.$to.pos, u, d, f, p;
		n.selection.empty ? r.doc.nodesBetween(s, l, (e, t) => {
			a && a === e.type && (c = !0, f = Math.max(t, s), p = Math.min(t + e.nodeSize, l), u = t, d = e);
		}) : r.doc.nodesBetween(s, l, (e, r) => {
			r < s && a && a === e.type && (c = !0, f = Math.max(r, s), p = Math.min(r + e.nodeSize, l), u = r, d = e), r >= s && r <= l && (a && a === e.type && (c = !0, i && n.setNodeMarkup(r, void 0, {
				...e.attrs,
				...t
			})), o && e.marks.length && e.marks.forEach((a) => {
				if (o === a.type && (c = !0, i)) {
					let i = Math.max(r, s), c = Math.min(r + e.nodeSize, l);
					n.addMark(i, c, o.create({
						...a.attrs,
						...t
					}));
				}
			}));
		}), d && (u !== void 0 && i && n.setNodeMarkup(u, void 0, {
			...d.attrs,
			...t
		}), o && d.marks.length && d.marks.forEach((e) => {
			o === e.type && i && n.addMark(f, p, o.create({
				...e.attrs,
				...t
			}));
		}));
	}), c;
}, Ln = new I("__tiptap_decorations__"), Rn = (e) => ({ tr: t, dispatch: n }) => (n && t.setMeta(Ln, {
	type: "force",
	name: e
}), !0), zn = (e, t = {}) => ({ state: n, dispatch: r }) => {
	let i = H(e, n.schema);
	return re(i, t)(n, r);
}, Bn = (e, t = {}) => ({ state: n, dispatch: r }) => {
	let i = H(e, n.schema);
	return ue(i, t)(n, r);
}, Vn = /* @__PURE__ */ Me({
	blur: () => Fe,
	clearContent: () => Ie,
	clearNodes: () => Le,
	command: () => Re,
	createParagraphNear: () => ze,
	cut: () => Be,
	deleteCurrentNode: () => Ve,
	deleteNode: () => He,
	deleteRange: () => Ue,
	deleteSelection: () => qe,
	enter: () => Je,
	exitCode: () => Ye,
	extendMarkRange: () => tt,
	first: () => nt,
	focus: () => st,
	forEach: () => ct,
	insertContent: () => lt,
	insertContentAt: () => mt,
	insertDefaultBlock: () => gt,
	joinBackward: () => yt,
	joinDown: () => vt,
	joinForward: () => bt,
	joinItemBackward: () => xt,
	joinItemForward: () => St,
	joinTextblockBackward: () => Ct,
	joinTextblockForward: () => wt,
	joinUp: () => _t,
	keyboardShortcut: () => Dt,
	lift: () => kt,
	liftEmptyBlock: () => At,
	liftListItem: () => jt,
	newlineInCode: () => Mt,
	resetAttributes: () => Ft,
	scrollIntoView: () => It,
	selectAll: () => Lt,
	selectNodeBackward: () => Rt,
	selectNodeForward: () => zt,
	selectParentNode: () => Bt,
	selectTextblockEnd: () => Vt,
	selectTextblockStart: () => Ht,
	setContent: () => Wt,
	setMark: () => pn,
	setMeta: () => mn,
	setNode: () => hn,
	setNodeSelection: () => gn,
	setTextDirection: () => _n,
	setTextSelection: () => vn,
	sinkListItem: () => yn,
	splitBlock: () => xn,
	splitListItem: () => Sn,
	toggleList: () => On,
	toggleMark: () => kn,
	toggleNode: () => An,
	toggleWrap: () => jn,
	undoInputRule: () => Mn,
	unsetAllMarks: () => Nn,
	unsetMark: () => Pn,
	unsetTextDirection: () => Fn,
	updateAttributes: () => In,
	updateDecorations: () => Rn,
	wrapIn: () => zn,
	wrapInList: () => Bn
});
typeof process < "u" && process.env.NODE_ENV;
function Hn(e) {
	return Object.prototype.toString.call(e).slice(8, -1);
}
function Un(e) {
	return Hn(e) === "Object" && e.constructor === Object && Object.getPrototypeOf(e) === Object.prototype;
}
function Wn(e, t) {
	let n = { ...e };
	return Un(e) && Un(t) && Object.keys(t).forEach((r) => {
		Un(t[r]) && Un(e[r]) ? n[r] = Wn(e[r], t[r]) : n[r] = t[r];
	}), n;
}
var Gn = class {
	constructor(e = {}) {
		this.type = "extendable", this.parent = null, this.child = null, this.name = "", this.config = { name: this.name }, this.config = {
			...this.config,
			...e
		}, this.name = this.config.name;
	}
	get options() {
		return { ...Zt(J(this, "addOptions", { name: this.name })) };
	}
	get storage() {
		return { ...Zt(J(this, "addStorage", {
			name: this.name,
			options: this.options
		})) };
	}
	configure(e = {}) {
		let t = this.extend({
			...this.config,
			addOptions: () => Wn(this.options, e)
		});
		return t.name = this.name, t.parent = this.parent, this.child = null, t;
	}
	extend(e = {}) {
		let t = new this.constructor({
			...this.config,
			...e
		});
		return t.parent = this, this.child = t, t.name = "name" in e ? e.name : t.parent.name, t;
	}
}, Y = class e extends Gn {
	constructor(...e) {
		super(...e), this.type = "extension";
	}
	static create(t = {}) {
		let n = typeof t == "function" ? t() : t;
		return new e(n);
	}
	configure(e) {
		return super.configure(e);
	}
	extend(e) {
		let t = typeof e == "function" ? e() : e;
		return super.extend(t);
	}
};
Y.create({
	name: "clipboardTextSerializer",
	addOptions() {
		return { blockSeparator: void 0 };
	},
	addProseMirrorPlugins() {
		return [new F({
			key: new I("clipboardTextSerializer"),
			props: { clipboardTextSerializer: () => {
				let { editor: e } = this, { state: t, schema: n } = e, { doc: r, selection: i } = t, a = rn(n), { blockSeparator: o } = this.options, s = {
					...o === void 0 ? {} : { blockSeparator: o },
					textSerializers: a
				};
				return [...i.ranges].sort((e, t) => e.$from.pos - t.$from.pos).map(({ $from: e, $to: t }) => nn(r, {
					from: e.pos,
					to: t.pos
				}, s)).join(o ?? "\n\n");
			} }
		})];
	}
}), Y.create({
	name: "commands",
	addCommands() {
		return { ...Vn };
	}
}), Y.create({
	name: "delete",
	onUpdate({ transaction: e, appendedTransactions: t }) {
		var n;
		let r = () => {
			var n, r;
			if (((n = this.editor.options.coreExtensionOptions) == null || (n = n.delete) == null || (r = n.filterTransaction) == null ? void 0 : r.call(n, e)) ?? e.getMeta("y-sync$")) return;
			let i = Kt(e.before, [e, ...t]);
			sn(i).forEach((t) => {
				i.mapping.mapResult(t.oldRange.from).deletedAfter && i.mapping.mapResult(t.oldRange.to).deletedBefore && i.before.nodesBetween(t.oldRange.from, t.oldRange.to, (n, r) => {
					let a = r + n.nodeSize - 2, o = t.oldRange.from <= r && a <= t.oldRange.to;
					this.editor.emit("delete", {
						type: "node",
						node: n,
						from: r,
						to: a,
						newFrom: i.mapping.map(r),
						newTo: i.mapping.map(a),
						deletedRange: t.oldRange,
						newRange: t.newRange,
						partial: !o,
						editor: this.editor,
						transaction: e,
						combinedTransform: i
					});
				});
			});
			let a = i.mapping;
			i.steps.forEach((t, n) => {
				if (t instanceof d) {
					let r = a.slice(n).map(t.from, -1), o = a.slice(n).map(t.to), s = a.invert().map(r, -1), c = a.invert().map(o), l = r > 0 && i.doc.nodeAt(r - 1)?.marks.some((e) => e.eq(t.mark)), u = i.doc.nodeAt(o)?.marks.some((e) => e.eq(t.mark));
					this.editor.emit("delete", {
						type: "mark",
						mark: t.mark,
						from: t.from,
						to: t.to,
						deletedRange: {
							from: s,
							to: c
						},
						newRange: {
							from: r,
							to: o
						},
						partial: !!(u || l),
						editor: this.editor,
						transaction: e,
						combinedTransform: i
					});
				}
			});
		};
		((n = this.editor.options.coreExtensionOptions) == null || (n = n.delete) == null ? void 0 : n.async) ?? !0 ? setTimeout(r, 0) : r();
	}
}), Y.create({
	name: "drop",
	addProseMirrorPlugins() {
		return [new F({
			key: new I("tiptapDrop"),
			props: { handleDrop: (e, t, n, r) => {
				this.editor.emit("drop", {
					editor: this.editor,
					event: t,
					slice: n,
					moved: r
				});
			} }
		})];
	}
}), Y.create({
	name: "editable",
	addProseMirrorPlugins() {
		return [new F({
			key: new I("editable"),
			props: { editable: () => this.editor.options.editable }
		})];
	}
});
var Kn = new I("focusEvents");
Y.create({
	name: "focusEvents",
	addProseMirrorPlugins() {
		let { editor: e } = this;
		return [new F({
			key: Kn,
			props: { handleDOMEvents: {
				focus: (t, n) => {
					e.isFocused = !0;
					let r = e.state.tr.setMeta("focus", { event: n }).setMeta("addToHistory", !1);
					return t.dispatch(r), !1;
				},
				blur: (t, n) => {
					e.isFocused = !1;
					let r = e.state.tr.setMeta("blur", { event: n }).setMeta("addToHistory", !1);
					return t.dispatch(r), !1;
				}
			} }
		})];
	}
}), Y.create({
	name: "keymap",
	addKeyboardShortcuts() {
		let e = () => this.editor.commands.first(({ commands: e }) => [
			() => e.undoInputRule(),
			() => e.command(({ tr: t }) => {
				let { selection: n, doc: r } = t, { empty: i, $anchor: a } = n, { pos: o, parent: s } = a, c = a.parent.isTextblock && o > 0 ? t.doc.resolve(o - 1) : a, l = c.parent.type.spec.isolating, u = a.pos - a.parentOffset, d = l && c.parent.childCount === 1 ? u === a.pos : L.atStart(r).from === o;
				return !i || !s.type.isTextblock || s.textContent.length || !d || d && a.parent.type.name === "paragraph" ? !1 : e.clearNodes();
			}),
			() => e.deleteSelection(),
			() => e.joinBackward(),
			() => e.selectNodeBackward()
		]), t = () => this.editor.commands.first(({ commands: e }) => [
			() => e.deleteSelection(),
			() => e.deleteCurrentNode(),
			() => e.joinForward(),
			() => e.selectNodeForward()
		]), n = {
			Enter: () => this.editor.commands.first(({ commands: e }) => [
				() => e.newlineInCode(),
				() => e.createParagraphNear(),
				() => e.liftEmptyBlock(),
				() => e.splitBlock()
			]),
			"Mod-Enter": () => this.editor.commands.exitCode(),
			Backspace: e,
			"Mod-Backspace": e,
			"Shift-Backspace": e,
			Delete: t,
			"Mod-Delete": t,
			"Mod-a": () => this.editor.commands.selectAll()
		}, r = { ...n }, i = {
			...n,
			"Ctrl-h": e,
			"Alt-Backspace": e,
			"Ctrl-d": t,
			"Ctrl-Alt-Backspace": t,
			"Alt-Delete": t,
			"Alt-d": t,
			"Ctrl-a": () => this.editor.commands.selectTextblockStart(),
			"Ctrl-e": () => this.editor.commands.selectTextblockEnd()
		};
		return G() || Tt() ? i : r;
	},
	addProseMirrorPlugins() {
		return [new F({
			key: new I("clearDocument"),
			appendTransaction: (e, t, n) => {
				if (e.some((e) => e.getMeta("composition"))) return;
				let r = e.some((e) => e.docChanged) && !t.doc.eq(n.doc), i = e.some((e) => e.getMeta("preventClearDocument"));
				if (!r || i) return;
				let { empty: a, from: o, to: s } = t.selection, c = L.atStart(t.doc).from, l = L.atEnd(t.doc).to;
				if (a || o !== c || s !== l || !dn(n.doc)) return;
				let u = n.tr, d = Ne({
					state: n,
					transaction: u
				}), { commands: f } = new Pe({
					editor: this.editor,
					state: d
				});
				if (f.clearNodes(), u.steps.length) return u;
			}
		})];
	}
}), Y.create({
	name: "paste",
	addProseMirrorPlugins() {
		return [new F({
			key: new I("tiptapPaste"),
			props: { handlePaste: (e, t, n) => {
				this.editor.emit("paste", {
					editor: this.editor,
					event: t,
					slice: n
				});
			} }
		})];
	}
}), Y.create({
	name: "tabindex",
	addOptions() {
		return { value: void 0 };
	},
	addProseMirrorPlugins() {
		return [new F({
			key: new I("tabindex"),
			props: { attributes: () => !this.editor.isEditable && this.options.value === void 0 ? {} : { tabindex: this.options.value ?? "0" } }
		})];
	}
}), Y.create({
	name: "textDirection",
	addOptions() {
		return { direction: void 0 };
	},
	addGlobalAttributes() {
		if (!this.options.direction) return [];
		let { nodeExtensions: e } = Qt(this.extensions);
		return [{
			types: e.filter((e) => e.name !== "text").map((e) => e.name),
			attributes: { dir: {
				default: this.options.direction,
				parseHTML: (e) => {
					let t = e.getAttribute("dir");
					return t && (t === "ltr" || t === "rtl" || t === "auto") ? t : this.options.direction;
				},
				renderHTML: (e) => e.dir ? { dir: e.dir } : {}
			} }
		}];
	},
	addProseMirrorPlugins() {
		return [new F({
			key: new I("textDirection"),
			props: { attributes: () => {
				let e = this.options.direction;
				return e ? { dir: e } : {};
			} }
		})];
	}
});
var qn = class e extends Gn {
	constructor(...e) {
		super(...e), this.type = "node";
	}
	static create(t = {}) {
		let n = typeof t == "function" ? t() : t;
		return new e(n);
	}
	configure(e) {
		return super.configure(e);
	}
	extend(e) {
		let t = typeof e == "function" ? e() : e;
		return super.extend(t);
	}
};
//#endregion
//#region src/ui/Editor/extensions/TableMarkdown.ts
function Jn(e) {
	return e.attrs.colspan > 1 || e.attrs.rowspan > 1;
}
function Yn(e) {
	let t = [];
	return e.forEach((e) => t.push(e)), t;
}
function Xn(e) {
	let t = Yn(e), n = t[0], r = t.slice(1);
	return !(Yn(n).some((e) => e.type.name !== "tableHeader" || Jn(e) || e.childCount > 1) || r.some((e) => Yn(e).some((e) => e.type.name === "tableHeader" || Jn(e) || e.childCount > 1)));
}
function Zn(e) {
	switch (e) {
		case "center": return ":---:";
		case "right": return "---:";
		case "left": return ":---";
		default: return "---";
	}
}
function Qn(e) {
	let t = new DOMParser().parseFromString(e, "text/html").body.firstElementChild;
	return t ? (t.innerHTML = t.innerHTML.trim() ? `\n${t.innerHTML}\n` : "\n", t.outerHTML) : e;
}
var $n = de.extend({ addStorage() {
	return { markdown: {
		serialize(e, t, n) {
			if (!Xn(t)) {
				if (this.editor.storage.markdown.options.html) {
					let r = Yt(z.from(t), t.type.schema), i = n instanceof z || n.type.name === t.type.schema.topNodeType.name;
					e.write(i ? Qn(r) : r);
				} else e.write("[table]");
				e.closeBlock(t);
				return;
			}
			e.inTable = !0, Yn(t);
			let r = [];
			t.forEach((t, n, i) => {
				if (e.write("| "), t.forEach((t, n, a) => {
					a && e.write(" | "), i === 0 && (r[a] = t.attrs.textAlign);
					let o = t.firstChild;
					o && o.textContent.trim() && e.renderInline(o);
				}), e.write(" |"), e.ensureNewLine(), !i) {
					let t = r.map((e) => Zn(e)).join(" | ");
					e.write(`| ${t} |`), e.ensureNewLine();
				}
			}), e.closeBlock(t), e.inTable = !1;
		},
		parse: {}
	} };
} }), er = Y.create({
	name: "fontSize",
	addOptions() {
		return { types: ["textStyle"] };
	},
	addGlobalAttributes() {
		return [{
			types: this.options.types,
			attributes: { fontSize: {
				default: null,
				parseHTML: (e) => e.style.fontSize || null,
				renderHTML: (e) => e.fontSize ? { style: `font-size: ${e.fontSize}` } : {}
			} }
		}];
	},
	addCommands() {
		return {
			setFontSize: (e) => ({ chain: t }) => t().setMark("textStyle", { fontSize: e }).run(),
			unsetFontSize: () => ({ chain: e }) => e().setMark("textStyle", { fontSize: null }).run()
		};
	}
}), tr = /^<!--\s*pagebreak\s*-->$/i, nr = qn.create({
	name: "pageBreak",
	group: "block",
	atom: !0,
	selectable: !0,
	parseHTML() {
		return [{ tag: "div[data-type=\"page-break\"]" }];
	},
	renderHTML({ HTMLAttributes: e }) {
		return ["div", tn(e, {
			"data-type": "page-break",
			class: "xmd-pagebreak"
		})];
	},
	addCommands() {
		return { insertPageBreak: () => ({ chain: e }) => e().insertContent({ type: this.name }).run() };
	},
	addStorage() {
		return { markdown: {
			serialize(e, t) {
				e.write("<!-- pagebreak -->"), e.closeBlock(t);
			},
			parse: { setup(e) {
				e.block.ruler.before("html_block", "pagebreak", (e, t, n, r) => {
					let i = e.bMarks[t] + e.tShift[t], a = e.eMarks[t], o = e.src.slice(i, a);
					if (!tr.test(o.trim())) return !1;
					if (r) return !0;
					let s = e.push("pagebreak", "div", 0);
					return s.map = [t, t + 1], s.attrSet("data-type", "page-break"), s.attrSet("class", "xmd-pagebreak"), e.line = t + 1, !0;
				}), e.renderer.rules.pagebreak = (e, t) => `<div data-type="page-break" class="xmd-pagebreak">${e[t].attrGet("hidden"), ""}</div>`;
			} }
		} };
	}
}), rr = /^<!--\s*empty-line\s*-->$/i, ir = Ae.extend({ addStorage() {
	return { markdown: {
		serialize(e, t) {
			if (t.content.size === 0) {
				e.write("<!-- empty-line -->"), e.closeBlock(t);
				return;
			}
			e.renderInline(t), e.closeBlock(t);
		},
		parse: { setup(e) {
			e.block.ruler.before("html_block", "empty_line", (e, t, n, r) => {
				let i = e.bMarks[t] + e.tShift[t], a = e.eMarks[t], o = e.src.slice(i, a);
				if (!rr.test(o.trim())) return !1;
				if (r) return !0;
				e.push("paragraph_open", "p", 1);
				let s = e.push("inline", "", 0);
				return s.content = "", s.children = [], e.push("paragraph_close", "p", -1), e.line = t + 1, !0;
			});
		} }
	} };
} });
//#endregion
//#region src/ui/Editor/pagination/slug.ts
function ar(e) {
	return e.toLowerCase().trim().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^a-z0-9\s-]/g, "").replace(/\s+/g, "-").replace(/-+/g, "-").replace(/^-|-$/g, "");
}
function or(e, t) {
	let n = ar(e) || "titre", r = n, i = 1;
	for (; t.has(r);) r = `${n}-${i}`, i += 1;
	return t.add(r), r;
}
//#endregion
//#region src/ui/Editor/extensions/TocMarker.ts
var sr = /^<!--\s*toc\s*-->$/i;
function cr(e) {
	let t = [];
	return e.descendants((e) => (e.type.name === "heading" && t.push({
		level: e.attrs.level,
		text: e.textContent
	}), !0)), t;
}
function lr(e) {
	if (e.length === 0) return {
		type: "paragraph",
		content: [{
			type: "text",
			text: "(Aucun titre dans le document)"
		}]
	};
	let t = /* @__PURE__ */ new Set(), n = e.map((e) => ({
		...e,
		slug: or(e.text, t)
	})), r = {
		level: 0,
		ownerListItem: null,
		items: []
	}, i = [r], a = () => {
		let e = i.pop();
		e.ownerListItem && e.items.length > 0 && e.ownerListItem.content.push({
			type: "bulletList",
			content: e.items
		});
	};
	for (let e of n) {
		for (; i.length > 1 && e.level <= i[i.length - 1].level;) a();
		let t = {
			type: "listItem",
			content: [{
				type: "paragraph",
				content: e.text ? [{
					type: "text",
					text: e.text,
					marks: [{
						type: "link",
						attrs: { href: `#${e.slug}` }
					}]
				}] : []
			}]
		};
		i[i.length - 1].items.push(t), i.push({
			level: e.level,
			ownerListItem: t,
			items: []
		});
	}
	for (; i.length > 1;) a();
	return {
		type: "bulletList",
		content: r.items
	};
}
var ur = qn.create({
	name: "tocMarker",
	group: "block",
	atom: !0,
	selectable: !0,
	parseHTML() {
		return [{ tag: "div[data-type=\"toc-marker\"]" }];
	},
	renderHTML({ HTMLAttributes: e }) {
		return ["div", tn(e, {
			"data-type": "toc-marker",
			class: "xmd-toc-marker"
		})];
	},
	addCommands() {
		return {
			insertTocMarker: () => ({ chain: e }) => e().insertContent({ type: this.name }).run(),
			generateToc: () => ({ tr: e, state: t, dispatch: n, chain: r }) => {
				let i = lr(cr(t.doc).filter((e) => e.level >= 1)), a = !1, o = [];
				if (t.doc.descendants((e, t) => (e.type.name === "tocMarker" && (a = !0, o.push(t)), !0)), !a) return r().insertContent(i).run();
				if (n) {
					for (let n = o.length - 1; n >= 0; n--) {
						let r = o[n], a = t.doc.nodeAt(r);
						if (!a) continue;
						let s = t.schema.nodeFromJSON(i);
						e.replaceWith(r, r + a.nodeSize, s);
					}
					n(e);
				}
				return !0;
			}
		};
	},
	addStorage() {
		return { markdown: {
			serialize(e, t) {
				e.write("<!-- toc -->"), e.closeBlock(t);
			},
			parse: { setup(e) {
				e.block.ruler.before("html_block", "tocmarker", (e, t, n, r) => {
					let i = e.bMarks[t] + e.tShift[t], a = e.eMarks[t], o = e.src.slice(i, a);
					if (!sr.test(o.trim())) return !1;
					if (r) return !0;
					let s = e.push("tocmarker", "div", 0);
					return s.map = [t, t + 1], s.attrSet("data-type", "toc-marker"), s.attrSet("class", "xmd-toc-marker"), e.line = t + 1, !0;
				}), e.renderer.rules.tocmarker = () => "<div data-type=\"toc-marker\" class=\"xmd-toc-marker\"></div>";
			} }
		} };
	}
}), dr = qn.create({
	name: "footnoteReference",
	group: "inline",
	inline: !0,
	atom: !0,
	selectable: !0,
	addAttributes() {
		return { id: { default: "1" } };
	},
	parseHTML() {
		return [{
			tag: "sup[data-type=\"footnote-ref\"]",
			priority: 100,
			getAttrs: (e) => ({ id: e.getAttribute("data-id") })
		}];
	},
	renderHTML({ node: e, HTMLAttributes: t }) {
		return [
			"sup",
			tn(t, {
				"data-type": "footnote-ref",
				"data-id": e.attrs.id,
				class: "xmd-footnote-ref"
			}),
			e.attrs.id
		];
	},
	addCommands() {
		return { insertFootnoteReference: (e) => ({ chain: t }) => t().insertContent({
			type: this.name,
			attrs: { id: e }
		}).run() };
	},
	addStorage() {
		return { markdown: {
			serialize(e, t) {
				e.write(`[^${t.attrs.id}]`);
			},
			parse: { setup(e) {
				e.inline.ruler.before("link", "footnote-ref", (e, t) => {
					let n = e.src, r = e.pos;
					if (n[r] !== "[" || n[r + 1] !== "^") return !1;
					let i = n.indexOf("]", r);
					if (i === -1) return !1;
					let a = n.slice(r + 2, i);
					if (!a || /[\s:]/.test(a)) return !1;
					if (!t) {
						let t = e.push("footnote_ref", "", 0);
						t.meta = { id: a };
					}
					return e.pos = i + 1, !0;
				}), e.renderer.rules.footnote_ref = (e, t) => {
					let { id: n } = e[t].meta;
					return `<sup data-type="footnote-ref" data-id="${n}" class="xmd-footnote-ref">${n}</sup>`;
				};
			} }
		} };
	}
}), fr = /^\[\^([^\]:\s]+)\]:\s?(.*)$/, pr = qn.create({
	name: "footnoteDefinition",
	group: "block",
	content: "inline*",
	addAttributes() {
		return { id: { default: "1" } };
	},
	parseHTML() {
		return [{
			tag: "div[data-type=\"footnote-def\"]",
			getAttrs: (e) => ({ id: e.getAttribute("data-id") })
		}];
	},
	renderHTML({ node: e, HTMLAttributes: t }) {
		return [
			"div",
			tn(t, {
				"data-type": "footnote-def",
				"data-id": e.attrs.id,
				class: "xmd-footnote-def"
			}),
			0
		];
	},
	addCommands() {
		return { insertFootnoteDefinition: (e) => ({ chain: t }) => t().insertContent({
			type: this.name,
			attrs: { id: e },
			content: []
		}).run() };
	},
	addStorage() {
		return { markdown: {
			serialize(e, t) {
				e.write(`[^${t.attrs.id}]: `), e.renderInline(t), e.closeBlock(t);
			},
			parse: { setup(e) {
				e.block.ruler.before("paragraph", "footnote-def", (e, t, n, r) => {
					let i = e.bMarks[t] + e.tShift[t], a = e.eMarks[t], o = e.src.slice(i, a).match(fr);
					if (!o) return !1;
					if (r) return !0;
					let s = e.push("footnote_def_open", "div", 1);
					s.attrSet("data-type", "footnote-def"), s.attrSet("data-id", o[1]), s.map = [t, t + 1];
					let c = e.push("inline", "", 0);
					return c.content = o[2], c.map = [t, t + 1], c.children = [], e.push("footnote_def_close", "div", -1), e.line = t + 1, !0;
				});
			} }
		} };
	}
}), mr = Y.create({ name: "mermaidDiagramAbsent" }), hr = Y.create({ name: "inlineMathAbsent" }), gr = Y.create({ name: "blockMathAbsent" }), _r = {
	name: "xmd-editor",
	private: !0,
	version: "0.4.5",
	license: "MIT",
	type: "module",
	scripts: {
		dev: "vite",
		build: "tsc && vite build",
		preview: "vite preview",
		"build:embed": "node scripts/build-embed.mjs",
		tauri: "tauri"
	},
	dependencies: {
		"@tauri-apps/api": "^2",
		"@tauri-apps/plugin-dialog": "^2.7.3",
		"@tauri-apps/plugin-opener": "^2",
		"@tiptap/extension-character-count": "^3.31.3",
		"@tiptap/extension-code-block-lowlight": "^3.31.3",
		"@tiptap/extension-color": "^3.31.3",
		"@tiptap/extension-font-family": "^3.31.3",
		"@tiptap/extension-highlight": "^3.31.3",
		"@tiptap/extension-image": "^3.31.3",
		"@tiptap/extension-link": "^3.31.3",
		"@tiptap/extension-paragraph": "^3.31.3",
		"@tiptap/extension-placeholder": "^3.31.3",
		"@tiptap/extension-subscript": "^3.31.3",
		"@tiptap/extension-superscript": "^3.31.3",
		"@tiptap/extension-table": "^3.31.3",
		"@tiptap/extension-table-cell": "^3.31.3",
		"@tiptap/extension-table-header": "^3.31.3",
		"@tiptap/extension-table-row": "^3.31.3",
		"@tiptap/extension-task-item": "^3.31.3",
		"@tiptap/extension-task-list": "^3.31.3",
		"@tiptap/extension-text-align": "^3.31.3",
		"@tiptap/extension-text-style": "^3.31.3",
		"@tiptap/extension-underline": "^3.31.3",
		"@tiptap/pm": "^3.31.3",
		"@tiptap/react": "^3.31.3",
		"@tiptap/starter-kit": "^3.31.3",
		katex: "^0.18.7",
		lowlight: "^3.3.0",
		mermaid: "^11.17.2",
		react: "^19.1.0",
		"react-dom": "^19.1.0",
		"tiptap-markdown": "^0.9.0",
		zustand: "^5.0.15"
	},
	devDependencies: {
		"@tauri-apps/cli": "^2",
		"@types/react": "^19.1.8",
		"@types/react-dom": "^19.1.6",
		"@vitejs/plugin-react": "^6.0.2",
		"playwright-core": "^1.63.0",
		typescript: "~6.0.3",
		vite: "^8.0.16"
	}
}, vr = "Pagina", yr = _r.version, br = "Mon BE Fluides", xr = "https://www.monbefluides.fr", Sr = "Dépôt GitHub public", Cr = {
	1: "20pt",
	2: "16pt",
	3: "13pt",
	4: "11pt",
	5: "10pt",
	6: "10pt"
};
function X(e) {
	return {
		fontFamily: "Arial, sans-serif",
		fontSize: Cr[e],
		color: "#2f52a0",
		bold: !0,
		italic: !1,
		numbering: "none"
	};
}
var Z = {
	1: X(1),
	2: X(2),
	3: X(3),
	4: X(4),
	5: X(5),
	6: X(6)
}, wr = [
	[1e3, "M"],
	[900, "CM"],
	[500, "D"],
	[400, "CD"],
	[100, "C"],
	[90, "XC"],
	[50, "L"],
	[40, "XL"],
	[10, "X"],
	[9, "IX"],
	[5, "V"],
	[4, "IV"],
	[1, "I"]
];
function Tr(e) {
	let t = e, n = "";
	for (let [e, r] of wr) for (; t >= e;) n += r, t -= e;
	return n;
}
function Er(e) {
	let t = e, n = "";
	for (; t > 0;) {
		let e = (t - 1) % 26;
		n = String.fromCharCode(65 + e) + n, t = Math.floor((t - 1) / 26);
	}
	return n;
}
function Dr(e, t) {
	switch (t) {
		case "decimal": return String(e);
		case "upperRoman": return Tr(e);
		case "lowerRoman": return Tr(e).toLowerCase();
		case "upperAlpha": return Er(e);
		case "lowerAlpha": return Er(e).toLowerCase();
		default: return "";
	}
}
var Or = {
	fontFamily: "Arial, sans-serif",
	fontSize: "10pt",
	lineHeight: 1.15,
	paragraphSpacingPt: 8,
	marginTopMm: 25,
	marginBottomMm: 25,
	marginLeftMm: 20,
	marginRightMm: 20,
	paperSize: "A4",
	orientation: "portrait",
	header: {
		text: "",
		heightMm: 12,
		showOnFirstPage: !0
	},
	footer: {
		text: "",
		heightMm: 12,
		showOnFirstPage: !0
	},
	documentVersion: "",
	author: "",
	headingStyles: Z
}, kr = {
	A4: {
		width: 210,
		height: 297
	},
	Letter: {
		width: 215.9,
		height: 279.4
	}
};
function Ar(e) {
	let t = kr[e.paperSize];
	return e.orientation === "landscape" ? {
		widthMm: t.height,
		heightMm: t.width
	} : {
		widthMm: t.width,
		heightMm: t.height
	};
}
var jr = {
	page: "{{page}}",
	pages: "{{pages}}",
	date: "{{date}}",
	filename: "{{filename}}",
	version: "{{version}}",
	author: "{{author}}"
};
function Mr(e, t) {
	let n = e;
	for (let e of Object.keys(jr)) n = n.split(jr[e]).join(String(t[e]));
	return n;
}
function Nr() {
	let e = /* @__PURE__ */ new Date();
	return `${String(e.getDate()).padStart(2, "0")}/${String(e.getMonth() + 1).padStart(2, "0")}/${e.getFullYear()}`;
}
var Pr = "<!-- pagina:config ", Fr = " -->", Ir = "<!-- pagina:generator ", Lr = " -->", Rr = /^<!--\s*pagina:(config|generator)\s+([\s\S]*?)\s*-->\s*\n?/, zr = 1;
function Br(e) {
	let t = e, n = Or;
	for (let e = 0; e < 2; e++) {
		let e = t.match(Rr);
		if (!e) break;
		let [r, i, a] = e;
		if (t = t.slice(r.length), i === "config") try {
			let e = JSON.parse(a), t = e.layout?.headingStyles;
			n = {
				...Or,
				...e.layout,
				header: {
					...Or.header,
					...e.layout?.header
				},
				footer: {
					...Or.footer,
					...e.layout?.footer
				},
				headingStyles: {
					1: {
						...Z[1],
						...t?.[1]
					},
					2: {
						...Z[2],
						...t?.[2]
					},
					3: {
						...Z[3],
						...t?.[3]
					},
					4: {
						...Z[4],
						...t?.[4]
					},
					5: {
						...Z[5],
						...t?.[5]
					},
					6: {
						...Z[6],
						...t?.[6]
					}
				}
			};
		} catch {}
	}
	return {
		layout: n,
		content: t
	};
}
function Vr(e) {
	return `${Pr}${JSON.stringify({
		configVersion: zr,
		layout: e
	})}${Fr}`;
}
function Hr() {
	return `${Ir}${JSON.stringify({
		app: vr,
		appVersion: yr,
		publisher: br,
		website: xr,
		license: Sr
	})}${Lr}`;
}
function Ur(e, t) {
	return `${Hr()}\n${Vr(e)}\n${t}`;
}
//#endregion
//#region src/ui/Editor/extensions/HeadingAutoNumber.ts
var Wr = /^(?:[0-9]+|[A-Za-z]+)(?:\.(?:[0-9]+|[A-Za-z]+))*\.\s+/;
function Gr(e, t, n) {
	let r = n[e];
	if (!r || r.numbering === "none") return "";
	let i = [];
	for (let r = 1; r <= e; r++) {
		let e = n[r];
		e && e.numbering !== "none" && i.push(Dr(t[r - 1], e.numbering));
	}
	return i.length > 0 ? `${i.join(".")}. ` : "";
}
function Kr(e, t) {
	if (!Object.values(t).some((e) => e.numbering !== "none")) return;
	let { state: n } = e, r = [
		0,
		0,
		0,
		0,
		0,
		0
	], i = n.tr, a = !1;
	n.doc.descendants((e, n) => {
		if (e.type.name !== "heading") return !0;
		let o = e.attrs.level ?? 1;
		r[o - 1] += 1;
		for (let e = o; e < 6; e++) r[e] = 0;
		let s = Gr(o, r, t), c = e.textContent.match(Wr), l = c ? c[0] : "";
		if (l === s) return !1;
		let u = i.mapping.map(n + 1), d = i.mapping.map(n + 1 + l.length);
		return i.insertText(s, u, d), a = !0, !1;
	}), a && (i.setMeta("addToHistory", !1), e.dispatch(i));
}
//#endregion
//#region src/ui/Editor/pagination/paginator.ts
function qr({ pageHeight: e, margins: t }) {
	let n = e - t.top - t.bottom;
	if (n <= 0) throw Error("createPaginator: la hauteur de page et les marges ne laissent aucune place au contenu");
	let r = [];
	function i() {
		let e = {
			pageNumber: r.length + 1,
			cursorY: 0,
			trailingSpacing: 0
		};
		return r.push(e), e;
	}
	function a() {
		return r.length > 0 ? r[r.length - 1] : i();
	}
	function o(e, t, r, o) {
		let s = a(), c = !1, l = 0;
		o && (s.cursorY !== 0 || s.trailingSpacing !== 0) && (l = n - s.cursorY, s = i(), c = !0);
		let u = t + s.trailingSpacing, d = u + e;
		return (Number.isFinite(d) && d > 0 ? d : 0) > n - s.cursorY && s.cursorY !== 0 && (l = n - s.cursorY, s = i(), c = !0), s.cursorY += u + e, s.trailingSpacing = r, {
			pageNumber: s.pageNumber,
			startsNewPage: c,
			previousPageLeftover: l
		};
	}
	return {
		placeBlock: o,
		get pageCount() {
			return Math.max(r.length, 1);
		}
	};
}
//#endregion
//#region src/ui/Editor/pagination/paintPages.ts
var Jr = "h1, h2, h3, h4, h5, h6", Q = "data-src-pos", Yr = "data-header-template", Xr = "data-footer-template";
function Zr(e, t, n) {
	let { pageHeightPx: r, marginTopPx: i, marginBottomPx: a, header: o, footer: s, context: c } = n, l = qr({
		pageHeight: r,
		margins: {
			top: i,
			bottom: a
		}
	}), u = [[]], d = !1;
	e.state.doc.forEach((t, n) => {
		let r = e.nodeDOM(n);
		if (!r || !(r instanceof HTMLElement)) return;
		let i = r.getBoundingClientRect().height, a = getComputedStyle(r), o = parseFloat(a.marginTop) || 0, s = parseFloat(a.marginBottom) || 0, c = l.placeBlock(i, o, s, d);
		for (d = t.type.name === "pageBreak"; u.length < c.pageNumber;) u.push([]);
		u[c.pageNumber - 1].push({
			pos: n,
			dom: r
		});
	});
	let f = u.length, p = /* @__PURE__ */ new Set();
	return t.replaceChildren(...u.map((e, t) => {
		let n = t + 1, r = t === 0, i = document.createElement("div");
		i.className = "xmd-page";
		let a = {
			...c,
			page: n,
			pages: f
		};
		if (o.showOnFirstPage || !r) {
			let e = document.createElement("div");
			e.className = "xmd-page-header", e.textContent = Mr(o.text, a), e.setAttribute(Yr, o.text), e.title = "Cliquer pour modifier l'en-tête", i.appendChild(e);
		}
		let l = document.createElement("div");
		l.className = "xmd-page-content xmd-prosemirror";
		for (let { pos: t, dom: n } of e) {
			let e = n.cloneNode(!0);
			e.setAttribute(Q, String(t));
			let r = e.matches(Jr) ? e : e.querySelector(Jr);
			r && (r.id = or(r.textContent ?? "", p)), l.appendChild(e);
		}
		if (i.appendChild(l), s.showOnFirstPage || !r) {
			let e = document.createElement("div");
			e.className = "xmd-page-footer", e.textContent = Mr(s.text, a), e.setAttribute(Xr, s.text), e.title = "Cliquer pour modifier le pied de page", i.appendChild(e);
		}
		return i;
	})), { pageCount: f };
}
//#endregion
//#region src/ui/Editor/pagination/resolveClickPosition.ts
function Qr(e, t, n, r, i) {
	let a = t, o = Infinity;
	for (let s = t; s <= n; s++) for (let t of [-1, 1]) {
		let n;
		try {
			n = e.coordsAtPos(s, t);
		} catch {
			continue;
		}
		let c = (n.top + n.bottom) / 2, l = Math.abs(c - i), u = Math.abs(n.left - r), d = l * 1e3 + u;
		d < o && (o = d, a = s);
	}
	return a;
}
function $r(e, t, n, r, i) {
	let a = r.getAttribute(Q);
	if (a === null) return null;
	let o = parseInt(a, 10), s = e.nodeDOM(o);
	if (!s || !(s instanceof HTMLElement)) return null;
	let c = e.state.doc.nodeAt(o);
	if (!c) return null;
	let l = r.getBoundingClientRect(), u = s.getBoundingClientRect(), d = (t - l.left) / i, f = (n - l.top) / i, p = u.left + d, m = u.top + f, h = o + 1, g = o + c.nodeSize - 1;
	return h > g ? o : Qr(e, h, g, p, m);
}
function ei(e) {
	return e instanceof HTMLElement ? e.closest(`[${Q}]`) : null;
}
//#endregion
//#region src/ui/Editor/pagination/caretPosition.ts
function ti(e, t, n, r) {
	let i;
	try {
		i = e.coordsAtPos(n);
	} catch {
		return null;
	}
	let a = e.state.doc.resolve(n), o = a.depth === 0 ? n : a.before(1), s = e.nodeDOM(o);
	if (!s || !(s instanceof HTMLElement)) return null;
	let c = t.querySelector(`[${Q}="${o}"]`);
	if (!c) return null;
	let l = s.getBoundingClientRect(), u = c.getBoundingClientRect(), d = t.parentElement.getBoundingClientRect(), f = i.left - l.left, p = i.top - l.top, m = i.bottom - i.top;
	return {
		left: u.left - d.left + f * r,
		top: u.top - d.top + p * r,
		height: m * r
	};
}
//#endregion
//#region src/ui/Editor/pagination/selectionHighlight.ts
function ni(e, t, n, r, i) {
	if (n >= r) return [];
	let a = t.parentElement.getBoundingClientRect(), o = [];
	return e.state.doc.forEach((s, c) => {
		let l = c, u = c + s.nodeSize, d = Math.max(n, l), f = Math.min(r, u);
		if (d >= f) return;
		let p = Math.max(d, l + 1), m = Math.min(f, u - 1);
		if (p >= m) return;
		let h = e.nodeDOM(c);
		if (!h || !(h instanceof HTMLElement)) return;
		let g = t.querySelector(`[${Q}="${c}"]`);
		if (!g) return;
		let _, v;
		try {
			_ = e.domAtPos(p), v = e.domAtPos(m);
		} catch {
			return;
		}
		let y = document.createRange();
		try {
			y.setStart(_.node, _.offset), y.setEnd(v.node, v.offset);
		} catch {
			return;
		}
		let b = h.getBoundingClientRect(), x = g.getBoundingClientRect();
		for (let e of Array.from(y.getClientRects())) {
			if (e.width === 0 && e.height === 0) continue;
			let t = e.left - b.left, n = e.top - b.top;
			o.push({
				left: x.left - a.left + t * i,
				top: x.top - a.top + n * i,
				width: e.width * i,
				height: e.height * i
			});
		}
	}), o;
}
//#endregion
//#region src/ui/Editor/MarkdownEditor.tsx
var ri = Oe(De);
Object.keys(De).sort();
function ii(e) {
	let t = document.createElement("div");
	t.style.height = `${e}mm`, t.style.position = "absolute", t.style.visibility = "hidden", document.body.appendChild(t);
	let n = t.getBoundingClientRect().height;
	return document.body.removeChild(t), n;
}
function ai(e) {
	for (let t of [
		1,
		2,
		3,
		4,
		5,
		6
	]) if (e.isActive("heading", { level: t })) return t;
	return "paragraph";
}
var oi = e(({ initialContent: e, onChange: t, onSaveRequest: o, onStats: d, layout: f, documentTitle: p, onLayoutChange: m, zoom: h = 1, onZoomChange: g, readOnly: _ = !1 }, v) => {
	let y = a(e), b = a(null), x = a(null), S = a(null), C = a(null), w = a(null), T = a(1), E = a(1), D = a(d);
	D.current = d;
	let O = a(h);
	O.current = h;
	let k = a(f);
	k.current = f;
	let ee = a(p);
	ee.current = p;
	let te = a(m);
	te.current = m;
	let A = a(() => {}), ne = a(() => {}), j = a(null), M = a(() => {}), re = a(() => {}), N = i(() => {
		let { widthMm: e, heightMm: t } = Ar(f);
		return {
			pageHeightPx: ii(t),
			marginTopPx: ii(f.marginTopMm),
			marginBottomPx: ii(f.marginBottomMm),
			contentWidthPx: ii(e - f.marginLeftMm - f.marginRightMm)
		};
	}, [f]), P = c({
		editable: !_,
		extensions: [
			l.configure({
				link: { openOnClick: !1 },
				codeBlock: !1,
				paragraph: !1
			}),
			Ee.configure({ lowlight: ri }),
			ir,
			u,
			$n.configure({ resizable: !0 }),
			fe,
			me,
			pe,
			he.configure({ placeholder: "Commencez à rédiger…" }),
			ge,
			_e,
			er,
			ve,
			ye.configure({ multicolor: !1 }),
			be.configure({ types: [
				"heading",
				"paragraph",
				"tableCell",
				"tableHeader"
			] }),
			xe,
			Se,
			Ce,
			we.configure({ nested: !0 }),
			Te,
			nr,
			ur,
			dr,
			pr,
			mr,
			hr,
			gr,
			ke.configure({
				html: !0,
				transformPastedText: !0
			})
		],
		content: e,
		editorProps: {
			attributes: {
				class: "xmd-prosemirror",
				spellcheck: "false",
				autocorrect: "off",
				autocapitalize: "off"
			},
			handleScrollToSelection: () => !0,
			handleKeyDown: (e, t) => (t.ctrlKey || t.metaKey) && t.key.toLowerCase() === "s" ? (t.preventDefault(), o(), !0) : (t.ctrlKey || t.metaKey) && t.key === "Enter" ? (t.preventDefault(), P?.chain().focus(void 0, { scrollIntoView: !1 }).insertContent({ type: "pageBreak" }).run(), !0) : !1
		},
		onUpdate: ({ editor: e }) => {
			let n = e.storage.markdown.getMarkdown();
			y.current = n, t(n), M.current();
		},
		onSelectionUpdate: ({ editor: e }) => {
			re.current();
			let t = e.storage.characterCount.words(), n = e.storage.characterCount.characters();
			D.current?.({
				words: t,
				characters: n,
				pageCount: T.current,
				currentPage: E.current,
				activeBlockStyle: ai(e)
			});
		}
	});
	n(() => {
		P?.setEditable(!_, !1);
	}, [P, _]), r(v, () => ({
		getMarkdown: () => P ? P.storage.markdown.getMarkdown() : y.current,
		getHTML: () => P?.getHTML() ?? "",
		focus: () => P?.commands.focus(),
		undo: () => P?.chain().focus(void 0, { scrollIntoView: !1 }).undo().run(),
		redo: () => P?.chain().focus(void 0, { scrollIntoView: !1 }).redo().run(),
		toggleBold: () => P?.chain().focus(void 0, { scrollIntoView: !1 }).toggleBold().run(),
		toggleItalic: () => P?.chain().focus(void 0, { scrollIntoView: !1 }).toggleItalic().run(),
		toggleUnderline: () => P?.chain().focus(void 0, { scrollIntoView: !1 }).toggleUnderline().run(),
		toggleStrike: () => P?.chain().focus(void 0, { scrollIntoView: !1 }).toggleStrike().run(),
		toggleHeading: (e) => P?.chain().focus(void 0, { scrollIntoView: !1 }).toggleHeading({ level: e }).run(),
		setParagraph: () => P?.chain().focus(void 0, { scrollIntoView: !1 }).setParagraph().run(),
		toggleBulletList: () => P?.chain().focus(void 0, { scrollIntoView: !1 }).toggleBulletList().run(),
		toggleOrderedList: () => P?.chain().focus(void 0, { scrollIntoView: !1 }).toggleOrderedList().run(),
		toggleBlockquote: () => P?.chain().focus(void 0, { scrollIntoView: !1 }).toggleBlockquote().run(),
		toggleCodeBlock: () => P?.chain().focus(void 0, { scrollIntoView: !1 }).toggleCodeBlock().run(),
		toggleCode: () => P?.chain().focus(void 0, { scrollIntoView: !1 }).toggleCode().run(),
		setCodeBlockLanguage: (e) => P?.chain().focus(void 0, { scrollIntoView: !1 }).updateAttributes("codeBlock", { language: e }).run(),
		setLink: () => {
			if (!P) return;
			let e = P.getAttributes("link").href, t = window.prompt("URL du lien :", e ?? "https://");
			if (t !== null) {
				if (t === "") {
					P.chain().focus(void 0, { scrollIntoView: !1 }).extendMarkRange("link").unsetLink().run();
					return;
				}
				P.chain().focus(void 0, { scrollIntoView: !1 }).extendMarkRange("link").setLink({ href: t }).run();
			}
		},
		insertImage: (e, t) => P?.chain().focus(void 0, { scrollIntoView: !1 }).setImage({
			src: e,
			alt: t
		}).run(),
		insertTable: () => P?.chain().focus(void 0, { scrollIntoView: !1 }).insertTable({
			rows: 3,
			cols: 3,
			withHeaderRow: !0
		}).run(),
		insertHorizontalRule: () => P?.chain().focus(void 0, { scrollIntoView: !1 }).setHorizontalRule().run(),
		insertPageBreak: () => P?.chain().focus(void 0, { scrollIntoView: !1 }).insertContent({ type: "pageBreak" }).run(),
		setFontFamily: (e) => P?.chain().focus(void 0, { scrollIntoView: !1 }).setFontFamily(e).run(),
		unsetFontFamily: () => P?.chain().focus(void 0, { scrollIntoView: !1 }).unsetFontFamily().run(),
		setFontSize: (e) => P?.chain().focus(void 0, { scrollIntoView: !1 }).setFontSize(e).run(),
		unsetFontSize: () => P?.chain().focus(void 0, { scrollIntoView: !1 }).unsetFontSize().run(),
		setColor: (e) => P?.chain().focus(void 0, { scrollIntoView: !1 }).setColor(e).run(),
		unsetColor: () => P?.chain().focus(void 0, { scrollIntoView: !1 }).unsetColor().run(),
		toggleHighlight: () => P?.chain().focus(void 0, { scrollIntoView: !1 }).toggleHighlight().run(),
		setTextAlign: (e) => P?.chain().focus(void 0, { scrollIntoView: !1 }).setTextAlign(e).run(),
		toggleSubscript: () => P?.chain().focus(void 0, { scrollIntoView: !1 }).toggleSubscript().run(),
		toggleSuperscript: () => P?.chain().focus(void 0, { scrollIntoView: !1 }).toggleSuperscript().run(),
		toggleTaskList: () => P?.chain().focus(void 0, { scrollIntoView: !1 }).toggleTaskList().run(),
		clearFormatting: () => P?.chain().focus(void 0, { scrollIntoView: !1 }).unsetAllMarks().unsetFontFamily().unsetFontSize().unsetColor().run(),
		getStats: () => ({
			words: P?.storage.characterCount.words() ?? 0,
			characters: P?.storage.characterCount.characters() ?? 0,
			activeBlockStyle: P ? ai(P) : "paragraph",
			pageCount: T.current,
			currentPage: E.current
		}),
		editHeader: () => {
			let e = x.current?.querySelector(".xmd-page-header");
			e && A.current(e);
		},
		editFooter: () => {
			let e = x.current?.querySelector(".xmd-page-footer");
			e && A.current(e);
		},
		insertHeaderFooterVariable: (e) => ne.current(e),
		insertTocMarker: () => P?.chain().focus(void 0, { scrollIntoView: !1 }).insertTocMarker().run(),
		generateToc: () => P?.chain().focus(void 0, { scrollIntoView: !1 }).generateToc().run(),
		insertFootnote: () => {
			if (!P) return;
			let e = 0;
			P.state.doc.descendants((t) => {
				if (t.type.name === "footnoteReference" || t.type.name === "footnoteDefinition") {
					let n = parseInt(t.attrs.id, 10);
					Number.isNaN(n) || (e = Math.max(e, n));
				}
			});
			let t = String(e + 1);
			P.chain().focus(void 0, { scrollIntoView: !1 }).insertFootnoteReference(t).run();
			let n = P.state.doc.content.size;
			P.chain().focus(void 0, { scrollIntoView: !1 }).setTextSelection(n).insertFootnoteDefinition(t).run(), P.state.doc.descendants((e, n) => {
				e.type.name === "footnoteDefinition" && e.attrs.id === t && P.chain().focus(void 0, { scrollIntoView: !1 }).setTextSelection(n + 1).run();
			});
		},
		insertMermaidDiagram: () => P?.chain().focus(void 0, { scrollIntoView: !1 }).insertContent({ type: "mermaidDiagram" }).run(),
		insertInlineMath: () => {
			let e = window.prompt("Formule LaTeX (en ligne) :", "E = mc^2");
			e && P?.chain().focus(void 0, { scrollIntoView: !1 }).insertContent({
				type: "inlineMath",
				attrs: { source: e }
			}).run();
		},
		insertBlockMath: () => {
			let e = window.prompt("Formule LaTeX (bloc) :", "\\int_0^\\infty e^{-x} dx = 1");
			e && P?.chain().focus(void 0, { scrollIntoView: !1 }).insertContent({
				type: "blockMath",
				attrs: { source: e }
			}).run();
		},
		insertEmoji: (e) => P?.chain().focus(void 0, { scrollIntoView: !1 }).insertContent(e).run()
	})), n(() => {
		P && e !== y.current && (P.commands.setContent(e), y.current = e);
	}, [e, P]), n(() => {
		if (!P) return;
		let e = () => {
			let e = x.current, t = S.current, n = C.current;
			if (!e || !t) return;
			let { from: r, to: i } = P.state.selection, a = r === i;
			if (n) {
				if (a) n.replaceChildren();
				else {
					let t = ni(P.view, e, r, i, O.current);
					n.replaceChildren(...t.map((e) => {
						let t = document.createElement("div");
						return t.className = "xmd-selection-rect", t.style.left = `${e.left}px`, t.style.top = `${e.top}px`, t.style.width = `${e.width}px`, t.style.height = `${e.height}px`, t;
					}));
				}
			}
			if (!a) {
				t.style.display = "none";
				return;
			}
			let o = ti(P.view, e, P.state.selection.head, O.current);
			o ? (t.style.display = "block", t.style.left = `${o.left}px`, t.style.top = `${o.top}px`, t.style.height = `${o.height}px`) : t.style.display = "none";
		};
		re.current = e;
		let t = () => {
			let t = x.current, n = w.current;
			if (!t) return;
			if (Kr(P.view, k.current.headingStyles), n) {
				let e = t.querySelector(".xmd-page-content");
				if (e) {
					let t = getComputedStyle(e), r = e.getBoundingClientRect().width - (parseFloat(t.paddingLeft) || 0) - (parseFloat(t.paddingRight) || 0);
					if (Math.abs(r - n.getBoundingClientRect().width) > .01) {
						n.style.width = `${r}px`;
						return;
					}
				}
			}
			let r = Zr(P.view, t, {
				pageHeightPx: N.pageHeightPx,
				marginTopPx: N.marginTopPx,
				marginBottomPx: N.marginBottomPx,
				header: f.header,
				footer: f.footer,
				context: {
					date: Nr(),
					filename: ee.current,
					version: f.documentVersion,
					author: f.author
				}
			});
			T.current = r.pageCount, e();
			let i = P.storage.characterCount.words(), a = P.storage.characterCount.characters();
			D.current?.({
				words: i,
				characters: a,
				pageCount: T.current,
				currentPage: E.current,
				activeBlockStyle: ai(P)
			});
		};
		M.current = t, t();
		let n = new ResizeObserver(t), r = P.view.dom;
		return n.observe(r), () => n.disconnect();
	}, [
		P,
		N,
		f
	]), n(() => {
		M.current();
	}, [h]);
	let F = (e) => {
		let t = e.classList.contains("xmd-page-header"), n = e.getAttribute(t ? "data-header-template" : "data-footer-template") ?? "", r = e.getBoundingClientRect(), i = document.createElement("input");
		i.type = "text", i.className = "xmd-header-footer-edit", i.value = n, i.style.left = `${r.left}px`, i.style.top = `${r.top}px`, i.style.width = `${r.width}px`, i.style.height = `${r.height}px`, document.body.appendChild(i), i.focus(), i.select(), j.current = i;
		let a = !1, o = () => {
			if (a) return;
			a = !0, j.current === i && (j.current = null);
			let e = i.value;
			i.remove();
			let n = k.current, r = t ? "header" : "footer";
			n[r].text !== e && te.current({
				...n,
				[r]: {
					...n[r],
					text: e
				}
			});
		}, s = () => {
			a || (a = !0, j.current === i && (j.current = null), i.remove());
		};
		i.addEventListener("blur", o), i.addEventListener("keydown", (e) => {
			e.key === "Enter" ? (e.preventDefault(), i.blur()) : e.key === "Escape" && (e.preventDefault(), s());
		});
	};
	A.current = F, ne.current = (e) => {
		let t = (t) => {
			let n = t.selectionStart ?? t.value.length, r = t.selectionEnd ?? t.value.length;
			t.value = t.value.slice(0, n) + e + t.value.slice(r);
			let i = n + e.length;
			t.focus(), t.setSelectionRange(i, i);
		}, n = j.current;
		if (n && document.body.contains(n)) {
			t(n);
			return;
		}
		let r = x.current?.querySelector(".xmd-page-header");
		if (!r) return;
		A.current(r);
		let i = j.current;
		i && (i.setSelectionRange(i.value.length, i.value.length), t(i));
	}, n(() => {
		let e = x.current;
		if (!e || !P) return;
		let t = !1, n = null, r = (e) => {
			let t = ei(e.target);
			return t ? $r(P.view, e.clientX, e.clientY, t, O.current) : null;
		}, i = (i) => {
			let a = i.target?.closest(".xmd-page-header, .xmd-page-footer");
			if (a) {
				i.preventDefault(), F(a);
				return;
			}
			let o = i.target?.closest("a[href^=\"#\"]");
			if (o) {
				i.preventDefault();
				let t = decodeURIComponent(o.getAttribute("href").slice(1));
				e.querySelector(`#${CSS.escape(t)}`)?.scrollIntoView({
					behavior: "smooth",
					block: "start"
				});
				return;
			}
			let s = i.target?.closest(".xmd-footnote-ref");
			if (s) {
				i.preventDefault();
				let t = s.getAttribute("data-id");
				e.querySelector(`.xmd-footnote-def[data-id="${CSS.escape(t ?? "")}"]`)?.scrollIntoView({
					behavior: "smooth",
					block: "start"
				});
				return;
			}
			if (i.target?.closest(".xmd-math")) {
				i.preventDefault();
				let e = r(i);
				if (e === null) return;
				let t = (e) => e && (e.type.name === "inlineMath" || e.type.name === "blockMath"), n = e, a = P.state.doc.nodeAt(n);
				if (t(a) || (n = e - 1, a = P.state.doc.nodeAt(n)), !t(a)) return;
				let o = window.prompt("Formule LaTeX :", a.attrs.source);
				if (o === null) return;
				P.view.dispatch(P.view.state.tr.setNodeAttribute(n, "source", o));
				return;
			}
			let c = r(i);
			c !== null && (i.preventDefault(), t = !0, n = c, P.commands.focus(void 0, { scrollIntoView: !1 }), P.commands.setTextSelection(c));
		}, a = (e) => {
			if (!t || n === null) return;
			let i = r(e);
			i !== null && P.commands.setTextSelection({
				from: n,
				to: i
			});
		}, o = () => {
			t = !1, n = null;
		}, s = (e) => {
			e.target?.closest("a") && e.preventDefault();
		};
		return e.addEventListener("mousedown", i), e.addEventListener("click", s), window.addEventListener("mousemove", a), window.addEventListener("mouseup", o), () => {
			e.removeEventListener("mousedown", i), e.removeEventListener("click", s), window.removeEventListener("mousemove", a), window.removeEventListener("mouseup", o);
		};
	}, [P]), n(() => {
		let e = b.current, t = x.current;
		if (!e || !t || !P) return;
		let n = !1, r = () => {
			n = !1;
			let r = Array.from(t.querySelectorAll(".xmd-page")), i = e.getBoundingClientRect().top + 40, a = 1;
			for (let e = 0; e < r.length; e++) r[e].getBoundingClientRect().top < i && (a = e + 1);
			if (a !== E.current) {
				E.current = a;
				let e = P.storage.characterCount.words(), t = P.storage.characterCount.characters();
				D.current?.({
					words: e,
					characters: t,
					pageCount: T.current,
					currentPage: a,
					activeBlockStyle: ai(P)
				});
			}
		}, i = () => {
			n || (n = !0, requestAnimationFrame(r));
		};
		return e.addEventListener("scroll", i, { passive: !0 }), r(), () => e.removeEventListener("scroll", i);
	}, [P]), n(() => {
		let e = b.current;
		if (!e || !g) return;
		let t = (e) => {
			e.ctrlKey && (e.preventDefault(), g(h + (e.deltaY > 0 ? -.1 : .1)));
		};
		return e.addEventListener("wheel", t, { passive: !1 }), () => e.removeEventListener("wheel", t);
	}, [h, g]);
	let { widthMm: I, heightMm: L } = Ar(f), R = {
		"--xmd-font-family": f.fontFamily,
		"--xmd-font-size": f.fontSize,
		"--xmd-line-height": f.lineHeight,
		"--xmd-paragraph-spacing": `${f.paragraphSpacingPt}pt`,
		"--xmd-zoom": h,
		"--xmd-page-height": `${L}mm`,
		"--xmd-page-width": `${I}mm`,
		"--xmd-margin-top": `${f.marginTopMm}mm`,
		"--xmd-margin-right": `${f.marginRightMm}mm`,
		"--xmd-margin-bottom": `${f.marginBottomMm}mm`,
		"--xmd-margin-left": `${f.marginLeftMm}mm`,
		"--xmd-header-height": `${f.header.heightMm}mm`,
		"--xmd-footer-height": `${f.footer.heightMm}mm`,
		...Object.fromEntries([
			1,
			2,
			3,
			4,
			5,
			6
		].flatMap((e) => {
			let t = f.headingStyles[e];
			return [
				[`--xmd-h${e}-font`, t.fontFamily],
				[`--xmd-h${e}-size`, t.fontSize],
				[`--xmd-h${e}-color`, t.color],
				[`--xmd-h${e}-weight`, t.bold ? "bold" : "normal"],
				[`--xmd-h${e}-style`, t.italic ? "italic" : "normal"]
			];
		}))
	};
	return /* @__PURE__ */ V("div", {
		className: "xmd-page-wrap",
		ref: b,
		style: R,
		children: [/* @__PURE__ */ B("div", {
			className: "xmd-live-editor-host",
			ref: w,
			style: { width: N.contentWidthPx },
			"aria-hidden": "true",
			children: /* @__PURE__ */ B(s, { editor: P })
		}), /* @__PURE__ */ V("div", {
			className: "xmd-canvas-frame",
			children: [
				/* @__PURE__ */ B("div", {
					className: "xmd-page-canvas",
					ref: x
				}),
				/* @__PURE__ */ B("div", {
					className: "xmd-selection-layer",
					ref: C
				}),
				/* @__PURE__ */ B("div", {
					className: "xmd-fake-caret",
					ref: S
				})
			]
		})]
	});
});
oi.displayName = "MarkdownEditor";
//#endregion
//#region src/ui/Toolbar/Toolbar.tsx
var si = [
	{
		label: "Numéro de page",
		token: "{{page}}"
	},
	{
		label: "Nombre de pages",
		token: "{{pages}}"
	},
	{
		label: "Date du jour",
		token: "{{date}}"
	},
	{
		label: "Nom du fichier",
		token: "{{filename}}"
	},
	{
		label: "Version du document",
		token: "{{version}}"
	},
	{
		label: "Auteur",
		token: "{{author}}"
	}
], ci = /* @__PURE__ */ "😀.😉.😂.🙂.😍.🤔.😢.😮.👍.👎.🙏.👏.💪.✅.❌.⚠️.❗.❓.💡.🔥.⭐.🎯.📌.📅.🕒.📎.🔗.📧.📞.🏗️".split("."), li = {
	1: 22,
	2: 19,
	3: 17,
	4: 15,
	5: 13,
	6: 12
}, ui = [
	{
		label: "Arial",
		value: "Arial, sans-serif"
	},
	{
		label: "Times New Roman",
		value: "'Times New Roman', serif"
	},
	{
		label: "Calibri",
		value: "Calibri, sans-serif"
	},
	{
		label: "Georgia",
		value: "Georgia, serif"
	},
	{
		label: "Courier New",
		value: "'Courier New', monospace"
	},
	{
		label: "Verdana",
		value: "Verdana, sans-serif"
	}
], di = [
	"8pt",
	"9pt",
	"10pt",
	"11pt",
	"12pt",
	"14pt",
	"16pt",
	"18pt",
	"24pt",
	"36pt"
], fi = /* @__PURE__ */ "javascript.typescript.python.java.c.cpp.csharp.html.css.scss.less.json.yaml.xml.markdown.bash.shell.sql.php.ruby.go.rust.swift.kotlin.r.lua.perl.graphql.makefile.ini.diff".split(".");
function pi({ actions: e, onToggleSidebar: t, sidebarOpen: n, onOpenPageSetup: r, onOpenHeadingStyles: i, activeBlockStyle: a = "paragraph", leger: s = !1 }) {
	let c = e === null, [l, u] = o("accueil");
	return /* @__PURE__ */ V("div", {
		className: "tb-ribbon-stack",
		children: [
			!s && /* @__PURE__ */ V("div", {
				className: "tb-tabbar",
				children: [
					/* @__PURE__ */ B("button", {
						className: `tb-tab${l === "accueil" ? " tb-tab-active" : ""}`,
						onClick: () => u("accueil"),
						children: "Accueil"
					}),
					/* @__PURE__ */ B("button", {
						className: `tb-tab${l === "avance" ? " tb-tab-active" : ""}`,
						onClick: () => u("avance"),
						title: "Mise en forme sans équivalent en Markdown standard (enregistrée en HTML dans le .md)",
						children: "Format avancé"
					}),
					/* @__PURE__ */ B("button", {
						className: `tb-tab${l === "extras" ? " tb-tab-active" : ""}`,
						onClick: () => u("extras"),
						title: "Diagrammes, formules mathématiques, emoji",
						children: "Extras"
					})
				]
			}),
			(s || l === "accueil") && /* @__PURE__ */ V("div", {
				className: "tb-ribbon",
				children: [
					!s && /* @__PURE__ */ V("button", {
						className: "tb-big-icon",
						onClick: t,
						title: n ? "Masquer l'explorateur" : "Afficher l'explorateur",
						children: [/* @__PURE__ */ B("span", {
							className: "tb-big-icon-glyph",
							children: "🗀"
						}), /* @__PURE__ */ B("span", {
							className: "tb-big-icon-label",
							children: "Explorateur"
						})]
					}),
					/* @__PURE__ */ V($, {
						label: "Police",
						launcher: s ? void 0 : { title: "Autres réglages de police (à venir)" },
						children: [
							/* @__PURE__ */ B("button", {
								className: "tb-btn-icon",
								disabled: c,
								onClick: () => e?.toggleBold(),
								title: "Gras (Ctrl+B)",
								children: /* @__PURE__ */ B("b", { children: "G" })
							}),
							/* @__PURE__ */ B("button", {
								className: "tb-btn-icon",
								disabled: c,
								onClick: () => e?.toggleItalic(),
								title: "Italique (Ctrl+I)",
								children: /* @__PURE__ */ B("i", { children: "I" })
							}),
							/* @__PURE__ */ B("button", {
								className: "tb-btn-icon",
								disabled: c,
								onClick: () => e?.toggleStrike(),
								title: "Texte barré",
								children: /* @__PURE__ */ B("s", { children: "S" })
							}),
							/* @__PURE__ */ B("button", {
								className: "tb-btn-icon",
								disabled: c,
								onClick: () => e?.toggleCode(),
								title: "Code en ligne — distinct du bloc de code (dans une phrase, ex. `variable`)",
								children: "</>"
							}),
							/* @__PURE__ */ B("button", {
								className: "tb-btn-icon",
								disabled: c,
								onClick: () => e?.toggleHighlight(),
								title: "Surlignage",
								children: "🖍️"
							})
						]
					}),
					/* @__PURE__ */ V($, {
						label: "Paragraphe",
						launcher: s ? void 0 : {
							onClick: r,
							title: "Mise en page (format, marges, en-tête/pied de page)"
						},
						children: [
							/* @__PURE__ */ B("button", {
								className: "tb-btn-icon",
								disabled: c,
								onClick: () => e?.toggleBulletList(),
								title: "Liste à puces",
								children: "☰•"
							}),
							/* @__PURE__ */ B("button", {
								className: "tb-btn-icon",
								disabled: c,
								onClick: () => e?.toggleOrderedList(),
								title: "Liste numérotée",
								children: "☰1"
							}),
							/* @__PURE__ */ B("button", {
								className: "tb-btn-icon",
								disabled: c,
								onClick: () => e?.toggleTaskList(),
								title: "Liste de tâches (case à cocher)",
								children: "☑"
							}),
							/* @__PURE__ */ B("button", {
								className: "tb-btn-icon",
								disabled: c,
								onClick: () => e?.toggleBlockquote(),
								title: "Citation",
								children: "❝"
							}),
							/* @__PURE__ */ B("button", {
								className: "tb-btn-icon",
								disabled: c,
								onClick: () => e?.insertPageBreak(),
								title: "Saut de page (Ctrl+Entrée) — commentaire HTML invisible, compatible partout",
								children: "⤓"
							}),
							/* @__PURE__ */ B("button", {
								className: "tb-btn-icon",
								disabled: c,
								onClick: () => e?.insertFootnote(),
								title: "Insérer une note de bas de page (numérotée automatiquement, ajoutée en fin de document)",
								children: "[^]"
							})
						]
					}),
					/* @__PURE__ */ B($, {
						label: "Styles",
						launcher: s ? void 0 : {
							onClick: i,
							title: "Styles de titres (police, couleur, numérotation automatique par niveau)"
						},
						children: /* @__PURE__ */ B(hi, {
							disabled: c,
							active: a,
							onPick: (t) => e?.toggleHeading(t),
							onPickParagraph: () => e?.setParagraph()
						})
					}),
					/* @__PURE__ */ V($, {
						label: "Liens et médias",
						children: [/* @__PURE__ */ B("button", {
							className: "tb-btn-icon",
							disabled: c,
							onClick: () => e?.setLink(),
							title: "Lien",
							children: "🔗"
						}), !s && /* @__PURE__ */ B("button", {
							className: "tb-btn-icon",
							disabled: c,
							onClick: () => e?.insertImage(),
							title: "Image",
							children: "🖼️"
						})]
					}),
					/* @__PURE__ */ V($, {
						label: "Éléments",
						children: [
							/* @__PURE__ */ B("button", {
								className: "tb-btn-icon",
								disabled: c,
								onClick: () => e?.insertTable(),
								title: "Tableau",
								children: "▦"
							}),
							/* @__PURE__ */ B("button", {
								className: "tb-btn-icon",
								disabled: c,
								onClick: () => e?.insertHorizontalRule(),
								title: "Séparateur",
								children: "─"
							}),
							/* @__PURE__ */ B("button", {
								className: "tb-btn-icon",
								disabled: c,
								onClick: () => e?.toggleCodeBlock(),
								title: "Bloc de code",
								children: "</>"
							}),
							/* @__PURE__ */ V("select", {
								className: "tb-select tb-select-narrow",
								disabled: c,
								defaultValue: "",
								title: "Langage du bloc de code (curseur dans un bloc de code)",
								onChange: (t) => {
									t.target.value && e?.setCodeBlockLanguage(t.target.value);
								},
								children: [/* @__PURE__ */ B("option", {
									value: "",
									children: "Langage"
								}), fi.map((e) => /* @__PURE__ */ B("option", {
									value: e,
									children: e
								}, e))]
							})
						]
					}),
					/* @__PURE__ */ V($, {
						label: "En-tête et pied de page",
						children: [
							/* @__PURE__ */ B("button", {
								className: "tb-btn",
								disabled: c,
								onClick: () => e?.editHeader(),
								title: "Modifier l'en-tête (identique à cliquer directement sur l'en-tête d'une page)",
								children: "En-tête"
							}),
							/* @__PURE__ */ B("button", {
								className: "tb-btn",
								disabled: c,
								onClick: () => e?.editFooter(),
								title: "Modifier le pied de page (identique à cliquer directement sur le pied de page d'une page)",
								children: "Pied de page"
							}),
							/* @__PURE__ */ B(_i, {
								disabled: c,
								onPick: (t) => e?.insertHeaderFooterVariable(t)
							})
						]
					}),
					/* @__PURE__ */ V($, {
						label: "Sommaire",
						children: [/* @__PURE__ */ B("button", {
							className: "tb-btn-icon",
							disabled: c,
							onClick: () => e?.insertTocMarker(),
							title: "Insérer un marqueur de sommaire (commentaire HTML invisible, compatible partout)",
							children: "☰+"
						}), /* @__PURE__ */ B("button", {
							className: "tb-btn-icon",
							disabled: c,
							onClick: () => e?.generateToc(),
							title: "Générer/mettre à jour le sommaire (remplace le marqueur par la liste réelle des titres)",
							children: "↻"
						})]
					})
				]
			}),
			!s && l === "avance" && /* @__PURE__ */ V("div", {
				className: "tb-ribbon",
				children: [/* @__PURE__ */ V($, {
					label: "Police",
					title: "Ces réglages n'existent pas en Markdown standard : ils sont enregistrés sous forme de balises HTML dans le fichier .md (toujours lisibles ailleurs, mais pas en syntaxe Markdown pure).",
					children: [/* @__PURE__ */ V("div", {
						className: "tb-group-row",
						children: [
							/* @__PURE__ */ V("select", {
								className: "tb-select",
								disabled: c,
								defaultValue: "",
								title: "Police",
								onChange: (t) => {
									t.target.value ? e?.setFontFamily(t.target.value) : e?.unsetFontFamily();
								},
								children: [/* @__PURE__ */ B("option", {
									value: "",
									children: "Police"
								}), ui.map((e) => /* @__PURE__ */ B("option", {
									value: e.value,
									style: { fontFamily: e.value },
									children: e.label
								}, e.value))]
							}),
							/* @__PURE__ */ V("select", {
								className: "tb-select tb-select-narrow",
								disabled: c,
								defaultValue: "",
								title: "Taille",
								onChange: (t) => {
									t.target.value ? e?.setFontSize(t.target.value) : e?.unsetFontSize();
								},
								children: [/* @__PURE__ */ B("option", {
									value: "",
									children: "Taille"
								}), di.map((e) => /* @__PURE__ */ B("option", {
									value: e,
									children: e
								}, e))]
							}),
							/* @__PURE__ */ B("button", {
								className: "tb-btn-icon",
								disabled: !0,
								title: "Agrandir la police (à venir)",
								children: "A˄"
							}),
							/* @__PURE__ */ B("button", {
								className: "tb-btn-icon",
								disabled: !0,
								title: "Réduire la police (à venir)",
								children: "A˅"
							}),
							/* @__PURE__ */ B("button", {
								className: "tb-btn-icon",
								disabled: !0,
								title: "Modifier la casse (à venir)",
								children: "Aa"
							}),
							/* @__PURE__ */ B("button", {
								className: "tb-btn-icon",
								disabled: c,
								onClick: () => e?.clearFormatting(),
								title: "Effacer toute la mise en forme avancée",
								children: "🧹"
							})
						]
					}), /* @__PURE__ */ V("div", {
						className: "tb-group-row",
						children: [
							/* @__PURE__ */ B("button", {
								className: "tb-btn-icon",
								disabled: c,
								onClick: () => e?.toggleUnderline(),
								title: "Souligné (Ctrl+U)",
								children: /* @__PURE__ */ B("u", { children: "S" })
							}),
							/* @__PURE__ */ B("button", {
								className: "tb-btn-icon",
								disabled: c,
								onClick: () => e?.toggleSubscript(),
								title: "Indice",
								children: "X₂"
							}),
							/* @__PURE__ */ B("button", {
								className: "tb-btn-icon",
								disabled: c,
								onClick: () => e?.toggleSuperscript(),
								title: "Exposant",
								children: "X²"
							}),
							/* @__PURE__ */ V("label", {
								className: "tb-btn-icon tb-color-swatch",
								title: "Couleur du texte",
								children: [
									"A",
									/* @__PURE__ */ B("span", {
										className: "tb-swatch-caret",
										children: "▾"
									}),
									/* @__PURE__ */ B("input", {
										type: "color",
										disabled: c,
										defaultValue: "#343334",
										onChange: (t) => e?.setColor(t.target.value)
									})
								]
							}),
							/* @__PURE__ */ V("button", {
								className: "tb-btn-icon tb-btn-with-caret",
								disabled: c,
								onClick: () => e?.toggleHighlight(),
								title: "Surlignage",
								children: ["🖍️", /* @__PURE__ */ B("span", {
									className: "tb-swatch-caret",
									children: "▾"
								})]
							})
						]
					})]
				}), /* @__PURE__ */ V($, {
					label: "Alignement",
					title: "Sans équivalent en Markdown standard, sérialisé en HTML.",
					children: [
						/* @__PURE__ */ B("button", {
							className: "tb-btn-icon",
							disabled: c,
							onClick: () => e?.setTextAlign("left"),
							title: "Aligner à gauche",
							children: /* @__PURE__ */ B(mi, { variant: "left" })
						}),
						/* @__PURE__ */ B("button", {
							className: "tb-btn-icon",
							disabled: c,
							onClick: () => e?.setTextAlign("center"),
							title: "Centrer",
							children: /* @__PURE__ */ B(mi, { variant: "center" })
						}),
						/* @__PURE__ */ B("button", {
							className: "tb-btn-icon",
							disabled: c,
							onClick: () => e?.setTextAlign("right"),
							title: "Aligner à droite",
							children: /* @__PURE__ */ B(mi, { variant: "right" })
						}),
						/* @__PURE__ */ B("button", {
							className: "tb-btn-icon",
							disabled: c,
							onClick: () => e?.setTextAlign("justify"),
							title: "Justifier",
							children: /* @__PURE__ */ B(mi, { variant: "justify" })
						})
					]
				})]
			}),
			!s && l === "extras" && /* @__PURE__ */ V("div", {
				className: "tb-ribbon",
				children: [
					/* @__PURE__ */ B($, {
						label: "Diagrammes",
						children: /* @__PURE__ */ B("button", {
							className: "tb-btn",
							disabled: c,
							onClick: () => e?.insertMermaidDiagram(),
							title: "Insérer un diagramme Mermaid (source éditable, aperçu rendu en direct)",
							children: "⛓ Mermaid"
						})
					}),
					/* @__PURE__ */ V($, {
						label: "Mathématiques",
						title: "Formules LaTeX, rendues via KaTeX.",
						children: [/* @__PURE__ */ B("button", {
							className: "tb-btn-icon",
							disabled: c,
							onClick: () => e?.insertInlineMath(),
							title: "Formule en ligne (dans une phrase)",
							children: "x²"
						}), /* @__PURE__ */ B("button", {
							className: "tb-btn-icon",
							disabled: c,
							onClick: () => e?.insertBlockMath(),
							title: "Formule en bloc (seule sur sa ligne, centrée)",
							children: "∑"
						})]
					}),
					/* @__PURE__ */ B(vi, {
						disabled: c,
						onPick: (t) => e?.insertEmoji(t)
					})
				]
			})
		]
	});
}
function mi({ variant: e }) {
	let t = [
		16,
		11,
		16,
		8
	].map((t) => {
		let n = 0;
		return e === "center" ? n = (16 - t) / 2 : e === "right" && (n = 16 - t), {
			x: e === "justify" ? 0 : n,
			width: e === "justify" ? 16 : t
		};
	});
	return /* @__PURE__ */ B("svg", {
		width: "16",
		height: "12",
		viewBox: "0 0 16 12",
		fill: "currentColor",
		"aria-hidden": "true",
		children: t.map((e, t) => /* @__PURE__ */ B("rect", {
			x: e.x,
			y: t * 3.2,
			width: e.width,
			height: "1.6",
			rx: "0.8"
		}, t))
	});
}
function $({ label: e, title: t, launcher: n, children: r }) {
	return /* @__PURE__ */ V("div", {
		className: "tb-group",
		children: [/* @__PURE__ */ B("div", {
			className: "tb-group-buttons",
			children: r
		}), /* @__PURE__ */ V("div", {
			className: "tb-group-caption",
			title: t,
			children: [e, n && /* @__PURE__ */ B("button", {
				type: "button",
				className: "tb-group-launcher",
				onClick: n.onClick,
				disabled: !n.onClick,
				title: n.title,
				children: "›"
			})]
		})]
	});
}
function hi({ disabled: e, active: t, onPick: n, onPickParagraph: r }) {
	return /* @__PURE__ */ V("div", {
		className: "tb-style-gallery",
		children: [
			/* @__PURE__ */ B("button", {
				className: `tb-style-btn${t === "paragraph" ? " tb-style-btn-active" : ""}`,
				disabled: e,
				onClick: r,
				title: "Normal",
				children: "Normal"
			}),
			[1, 2].map((r) => /* @__PURE__ */ V("button", {
				className: `tb-style-btn${t === r ? " tb-style-btn-active" : ""}`,
				disabled: e,
				onClick: () => n(r),
				title: `Titre ${r}`,
				children: ["Titre ", r]
			}, r)),
			/* @__PURE__ */ B(gi, {
				disabled: e,
				onPick: n
			})
		]
	});
}
function gi({ disabled: e, onPick: t }) {
	let [r, i] = o(!1), s = a(null);
	return n(() => {
		if (!r) return;
		let e = (e) => {
			s.current && !s.current.contains(e.target) && i(!1);
		};
		return document.addEventListener("mousedown", e), () => document.removeEventListener("mousedown", e);
	}, [r]), /* @__PURE__ */ V("div", {
		className: "tb-heading-picker",
		ref: s,
		children: [/* @__PURE__ */ B("button", {
			className: "tb-btn-icon tb-heading-picker-trigger",
			disabled: e,
			onClick: () => i((e) => !e),
			title: "Autres niveaux de titre",
			children: "⌄"
		}), r && /* @__PURE__ */ B("div", {
			className: "tb-heading-menu",
			children: [
				1,
				2,
				3,
				4,
				5,
				6
			].map((e) => /* @__PURE__ */ V("button", {
				className: "tb-heading-option",
				style: { fontSize: li[e] },
				onClick: () => {
					t(e), i(!1);
				},
				children: ["Titre ", e]
			}, e))
		})]
	});
}
function _i({ disabled: e, onPick: t }) {
	let [r, i] = o(!1), s = a(null);
	return n(() => {
		if (!r) return;
		let e = (e) => {
			s.current && !s.current.contains(e.target) && i(!1);
		};
		return document.addEventListener("mousedown", e), () => document.removeEventListener("mousedown", e);
	}, [r]), /* @__PURE__ */ V("div", {
		className: "tb-heading-picker",
		ref: s,
		children: [/* @__PURE__ */ B("button", {
			className: "tb-btn tb-heading-picker-trigger",
			disabled: e,
			onMouseDown: (e) => e.preventDefault(),
			onClick: () => i((e) => !e),
			title: "Insérer une variable dans l'en-tête/le pied de page (numéro de page, date...)",
			children: "Variable ▾"
		}), r && /* @__PURE__ */ B("div", {
			className: "tb-heading-menu",
			children: si.map(({ label: e, token: n }) => /* @__PURE__ */ V("button", {
				className: "tb-heading-option",
				onMouseDown: (e) => e.preventDefault(),
				onClick: () => {
					t(n), i(!1);
				},
				children: [
					e,
					" ",
					/* @__PURE__ */ B("span", {
						className: "tb-heading-option-token",
						children: n
					})
				]
			}, n))
		})]
	});
}
function vi({ disabled: e, onPick: t }) {
	let [r, i] = o(!1), s = a(null);
	return n(() => {
		if (!r) return;
		let e = (e) => {
			s.current && !s.current.contains(e.target) && i(!1);
		};
		return document.addEventListener("mousedown", e), () => document.removeEventListener("mousedown", e);
	}, [r]), /* @__PURE__ */ V("div", {
		className: "tb-heading-picker",
		ref: s,
		children: [/* @__PURE__ */ B("button", {
			className: "tb-btn tb-heading-picker-trigger",
			disabled: e,
			onClick: () => i((e) => !e),
			title: "Insérer un emoji",
			children: "😀 Emoji ▾"
		}), r && /* @__PURE__ */ B("div", {
			className: "tb-emoji-menu",
			children: ci.map((e) => /* @__PURE__ */ B("button", {
				className: "tb-emoji-option",
				onClick: () => {
					t(e), i(!1);
				},
				children: e
			}, e))
		})]
	});
}
//#endregion
//#region src/embed/PaginaLight.tsx
var yi = [
	.5,
	.75,
	1,
	1.25,
	1.5
], bi = {
	words: 0,
	characters: 0,
	pageCount: 1,
	currentPage: 1,
	activeBlockStyle: "paragraph"
}, xi = () => {};
function Si({ value: e, onChange: r, onSave: s, documentTitle: c = "Document", height: l = 640, resetKey: u = 0, readOnly: d = !1 }) {
	let f = i(() => Br(e), [u]), [p, m] = o(f.layout), [h, g] = o(bi), [_, v] = o(1), [y, b] = o(null), x = a(null), S = a(f.content), C = a(p);
	C.current = p;
	let w = a(r);
	w.current = r;
	let T = a(s);
	T.current = s;
	let E = a(!1), D = a(u);
	D.current !== u && (D.current = u, E.current = !1);
	let O = () => {
		E.current = !0;
	};
	n(() => {
		m(f.layout), S.current = f.content;
	}, [f]);
	let k = t((e, t) => {
		w.current(Ur(t, e));
	}, []);
	n(() => {
		let e = x.current;
		e && b({
			undo: () => e.undo(),
			redo: () => e.redo(),
			toggleBold: () => e.toggleBold(),
			toggleItalic: () => e.toggleItalic(),
			toggleUnderline: () => e.toggleUnderline(),
			toggleStrike: () => e.toggleStrike(),
			toggleHeading: (t) => e.toggleHeading(t),
			setParagraph: () => e.setParagraph(),
			toggleBulletList: () => e.toggleBulletList(),
			toggleOrderedList: () => e.toggleOrderedList(),
			toggleBlockquote: () => e.toggleBlockquote(),
			toggleCodeBlock: () => e.toggleCodeBlock(),
			toggleCode: () => e.toggleCode(),
			setCodeBlockLanguage: (t) => e.setCodeBlockLanguage(t),
			setLink: () => e.setLink(),
			insertImage: () => {},
			insertTable: () => e.insertTable(),
			insertHorizontalRule: () => e.insertHorizontalRule(),
			insertPageBreak: () => e.insertPageBreak(),
			setFontFamily: (t) => e.setFontFamily(t),
			unsetFontFamily: () => e.unsetFontFamily(),
			setFontSize: (t) => e.setFontSize(t),
			unsetFontSize: () => e.unsetFontSize(),
			setColor: (t) => e.setColor(t),
			toggleHighlight: () => e.toggleHighlight(),
			setTextAlign: (t) => e.setTextAlign(t),
			toggleSubscript: () => e.toggleSubscript(),
			toggleSuperscript: () => e.toggleSuperscript(),
			toggleTaskList: () => e.toggleTaskList(),
			clearFormatting: () => e.clearFormatting(),
			editHeader: () => e.editHeader(),
			editFooter: () => e.editFooter(),
			insertHeaderFooterVariable: (t) => e.insertHeaderFooterVariable(t),
			insertTocMarker: () => e.insertTocMarker(),
			generateToc: () => e.generateToc(),
			insertFootnote: () => e.insertFootnote(),
			insertMermaidDiagram: () => {},
			insertInlineMath: () => {},
			insertBlockMath: () => {},
			insertEmoji: (t) => e.insertEmoji(t)
		});
	}, [u]);
	let ee = typeof l == "number" ? `${l}px` : l;
	return /* @__PURE__ */ V("div", {
		className: "xmd-embed",
		style: { height: ee },
		onKeyDownCapture: O,
		onBeforeInputCapture: O,
		onPasteCapture: O,
		onCutCapture: O,
		onDropCapture: O,
		children: [
			/* @__PURE__ */ B("div", {
				onMouseDownCapture: O,
				children: /* @__PURE__ */ B(pi, {
					leger: !0,
					actions: d ? null : y,
					onToggleSidebar: xi,
					sidebarOpen: !1,
					onOpenPageSetup: xi,
					onOpenHeadingStyles: xi,
					activeBlockStyle: h.activeBlockStyle
				})
			}),
			/* @__PURE__ */ B("div", {
				className: "xmd-embed-editor-area",
				children: /* @__PURE__ */ B(oi, {
					ref: x,
					initialContent: f.content,
					onChange: (e) => {
						S.current = e, E.current && k(e, C.current);
					},
					onSaveRequest: () => T.current?.(),
					onStats: g,
					layout: p,
					documentTitle: c,
					onLayoutChange: (e) => {
						m(e), E.current && k(S.current, e);
					},
					readOnly: d,
					zoom: _,
					onZoomChange: (e) => v(Math.min(1.5, Math.max(.5, e)))
				}, u)
			}),
			/* @__PURE__ */ V("div", {
				className: "xmd-embed-statusbar",
				children: [
					/* @__PURE__ */ V("span", { children: [
						"Page ",
						h.currentPage,
						" / ",
						h.pageCount
					] }),
					/* @__PURE__ */ V("span", { children: [h.words, " mots"] }),
					/* @__PURE__ */ B("span", { className: "xmd-embed-statusbar-spacer" }),
					/* @__PURE__ */ V("label", { children: [
						"Zoom",
						" ",
						/* @__PURE__ */ B("select", {
							className: "xmd-embed-zoom",
							value: _,
							onChange: (e) => v(Number(e.target.value)),
							children: yi.map((e) => /* @__PURE__ */ V("option", {
								value: e,
								children: [Math.round(e * 100), " %"]
							}, e))
						})
					] })
				]
			})
		]
	});
}
//#endregion
export { Si as PaginaLight };
